﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace FXCalculation
{
    public class Program
    {
        
        static void Main(string[] args)
        {            
            SqlConnection connectionObject = new SqlConnection(@"Data Source=PC\MYSQLSERVER;Initial Catalog= DBFXCalculation;Integrated Security=True");
            FXCalculator fxcalculatorobj = new FXCalculator();
            fxcalculatorobj.ProcessData(@"D:\DotNetCAassessment\FXCalculation\Input File\", "TradeOrders_032013.txt", 
                @"D:\DotNetCAassessment\FXCalculation\ErrorLog\", "InvalidRecords_032013.txt", connectionObject,
                @"D:\Dotnetcaassessment\FXCalculator\Archive\", "TradeOrders_032013_Processed.txt");

           /*
           * Pass the file path, file names and connection string in this method alone. 
           * Do not hardcode in any other methods
           */ 
        }
    }
}
