using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using System.Data.SqlClient;
using System.Globalization;

/*
        * Do not remove the attached FXCalculationTestProject. It is meant for auto evaluation of your source code.
        * Do not attach any test classess to the attached test project.
        * Do not attach any new test projects.
        * You are supposed to write only the code. You are not required to write any automated test cases.
        * Do not create the redundant connection Object for SqlConnection, use the conncetionObject given in the method parameter.
        * Implement the exception method, Where its needed.
        * Open and Close the database connection properly.
        */
namespace FXCalculation
{
    public class FXCalculator
    {

        public void ProcessData(string sourceFolder, string fileName, string errorLogFilePath, 
            string errorLogFileName, SqlConnection connectionObject,
            string archiveFilePath, string archiveFileName)
        {

            //Do your logic here            

            //Step 1:ReadAllDataFromInputFile
            List<Trade> trades = ReadAllDataFromInputFile(sourceFolder, fileName);

            //Step 2:PickValidTradeDetails;
            List<Trade> validateTrade = PickValidTradeDetails(trades, errorLogFilePath, errorLogFileName);

            //Step 3: SaveValidRecordsToDB            
            SaveValidRecordsToDB(validateTrade, connectionObject);

            //Step 4:CalculateFXRate             
            CalculateFXRate(connectionObject);

            //Step 5:SaveFXRate  
            List<FXRate> fxRates = new List<FXRate>();
             SaveFXRate(fxRates,connectionObject);

            //Step 6:CopyToArchive        
            CopyToArchive(archiveFilePath, archiveFileName);

            //Validate data

        }
        
        public List<Trade> ReadAllDataFromInputFile(string sourceFolder, string fileName)
        {
            List<Trade> trades = new List<Trade>();
            //Do your logic to read file and storing it into list of trades ..here..
            //Do not hardcode the filename and the file path here
            string readLine = string.Empty;

            readLine = File.ReadAllText(sourceFolder + fileName);
            readLine = readLine.Replace("\r", "");
            string[] readLines = readLine.Split('\n');  
            List<string> innerList = readLines.ToList();
            foreach (var item in innerList)
            {
                if (item.Contains(','))
                {
                    string[] items = item.Split(',');
                    Trade tradeItem = new Trade();
                    tradeItem.TradeId = items[0];
                    tradeItem.ISIN = items[1];
                    tradeItem.TradeDate = items[2];
                    tradeItem.MaturityDate = items[3];
                    tradeItem.SchemeName = items[4];
                    tradeItem.TradeType = items[5];
                    tradeItem.Currency = items[6];
                    tradeItem.Amount = items[7];
                    trades.Add(tradeItem);
                }
            }
            return trades;
        }
        public List<Trade> PickValidTradeDetails(List<Trade> trades, string errorLogFilePath, string errorLogFileName)
        {
            // Step 1 : filter the valid trades and invalid trades, save the invalid
            List<Trade> validTrades = new List<Trade>(); //identify all the valid trades and assign.
            //Do not hardcode the filename and the file path here

            List<Trade> invalidTrade = new List<Trade>();

            bool isValid = true;

            foreach (var trade in trades)
            {
                isValid = false;
                if (!string.IsNullOrWhiteSpace(trade.TradeId) && trade.TradeId.StartsWith("TR"))
                {
                    if (!string.IsNullOrWhiteSpace(trade.ISIN) && trade.ISIN.StartsWith("ISIN"))
                    {
                        string num = trade.ISIN.Substring(4);
                        int i = 0;
                        if (int.TryParse(num, out i) & num.Length == 3)
                        {
                            DateTime tradeDateValue;
                            if (DateTime.TryParseExact(trade.TradeDate, "MM/dd/yyyy",
                                CultureInfo.InvariantCulture,
                                DateTimeStyles.None, out tradeDateValue))
                                tradeDateValue = Convert.ToDateTime(trade.TradeDate);
                            {
                                DateTime maturityDateValue;
                                if (DateTime.TryParseExact(trade.MaturityDate, "MM/dd/yyyy",
                                    CultureInfo.InvariantCulture,
                                    DateTimeStyles.None, out maturityDateValue))
                                    maturityDateValue = Convert.ToDateTime(trade.MaturityDate);
                                double totalDays = (maturityDateValue - tradeDateValue).TotalDays;
                                double noOfYears = totalDays / 365;
                                if (noOfYears > 5)
                                {
                                    if (!string.IsNullOrWhiteSpace(trade.SchemeName))
                                    {
                                        if (!string.IsNullOrWhiteSpace(trade.TradeType))
                                        {
                                            if (!string.IsNullOrWhiteSpace(trade.Currency)
                                                && trade.Currency.Length == 3)
                                            {
                                                if (!string.IsNullOrWhiteSpace(trade.Amount))
                                                {
                                                    isValid = true;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                try
                {
                    if (isValid)
                    {
                        validTrades.Add(trade);
                    }
                    else
                    {
                        invalidTrade.Add(trade);
                    }
                }
                catch(Exception ex)
                {
                    throw new FXCalculatorException(ex.Message);
                }
            }


            // SaveInvalidRecordsToLogFile(List<Trades>); // pass all the invalid trades to log...
            SaveInvalidRecordsToLogFile(invalidTrade, errorLogFilePath, errorLogFileName);

            return validTrades;
        }
        public bool SaveInvalidRecordsToLogFile(List<Trade> invalidTrades, string errorLogFilePath, string errorLogFileName)
        {
            //Do your logic here
            //Do not hardcode the filename and the file path here
            if (invalidTrades != null && invalidTrades.Count > 0)
            {
                string path = errorLogFilePath + errorLogFileName;

                try
                {
                    if (!File.Exists(path))
                    {
                        using (StreamWriter tw = File.CreateText(path))
                        {
                            tw.WriteLine("TradeId|ISIN|TradeDate|MaturityDate|SchemeName|TradeType|Currency|Amount");

                            foreach (var trade in invalidTrades)
                            {
                                tw.WriteLine(trade.TradeId + "," + trade.ISIN + "," + trade.TradeDate + "," +
                                    trade.MaturityDate + "," + trade.SchemeName + "," + trade.TradeType + "," +
                                    trade.Currency + "," + trade.Amount);
                            }
                            tw.Close();
                        }
                    }
                    else if (File.Exists(path))
                    {
                        using (var tw = new StreamWriter(path, true))
                        {
                            foreach (var trade in invalidTrades)
                            {
                                tw.WriteLine(trade.TradeId + "," + trade.ISIN + "," + trade.TradeDate + "," +
                                    trade.MaturityDate + "," + trade.SchemeName + "," + trade.TradeType + "," +
                                    trade.Currency + "," + trade.Amount);
                            }
                            tw.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw new FXCalculatorException(ex.Message);
                }
            }
            return true;
        }
        public bool SaveValidRecordsToDB(List<Trade> validTrades, SqlConnection sqlConnectionObject)
        {
            //Do your logic here to upload to DB table
            //Do not hardcode the connection string here
            //Do not create the redundant connection Object for SqlConnection, use the conncetionObject given in the method parameter.
            //Do not Prefix Database name in the SQL Query. Query should be "Insert into SBA.TableName"
            //Should not be "Insert into DatabaseName.SBA.TableName"
            //var ConnectionString = sqlConnectionObject.ConnectionString;
            if (validTrades != null && validTrades.Count > 0)
            {
                foreach (var trade in validTrades)
                {
                    try
                    {
                        //using (sqlConnectionObject = new SqlConnection(ConnectionString))
                        //{
                            using (SqlCommand command = sqlConnectionObject.CreateCommand())
                            {
                                command.CommandText = "INSERT INTO SBA.Trade_Details (TradeId, ISIN, TradeDate, MaturityDate,SchemeName, TradeType, Currency, Amount) VALUES(@TradeId,@ISIN, @TradeDate, @MaturityDate, @SchemeName, @TradeType, @Currency, @Amount)";
                                command.Parameters.AddWithValue("@TradeId", trade.TradeId);
                                command.Parameters.AddWithValue("@ISIN", trade.ISIN);
                                command.Parameters.AddWithValue("@TradeDate", trade.TradeDate);
                                command.Parameters.AddWithValue("@MaturityDate", trade.MaturityDate);
                                command.Parameters.AddWithValue("@SchemeName", trade.SchemeName);
                                command.Parameters.AddWithValue("@TradeType", trade.TradeType);
                                command.Parameters.AddWithValue("@Currency", trade.Currency);
                                command.Parameters.AddWithValue("@Amount", trade.Amount);

                                sqlConnectionObject.Open();
                                command.ExecuteNonQuery();
                                sqlConnectionObject.Close();
                            }
                        //}
                    }
                    catch (Exception ex)
                    {
                        throw new FXCalculatorException(ex.Message);
                    }
                }
            }
            return true;
        }
        public List<FXRate> CalculateFXRate(SqlConnection sqlConnectionObject)
        {
            // TODO :Read the Trade details for TradeType FX from database and  calculate the rates.
            //  Calculate the rate for each trade and add in a list of FXRates. 
            //Do not Prefix Database name in the SQL Query. Query should be "Insert into SBA.TableName"
            //Should not be "Insert into DatabaseName.SBA.TableName"
            //List<FXRate> FxRates = null; // assign list of FXRates;
            //Do not hardcode the connection string here
            //Do not create the redundant connection Object for SqlConnection, use the conncetionObject given in the method parameter.
            List<FXRate> FxRates = new List<FXRate>();
            List<Trade> trades = new List<Trade>();
            //var connectionstring = sqlConnectionObject.ConnectionString;
            try
            {
                //using (sqlConnectionObject = new SqlConnection(connectionstring))
                //{
                    string queryString = "Select * from SBA.Trade_Details";
                    SqlCommand command = new SqlCommand(queryString, sqlConnectionObject);
                    sqlConnectionObject.Open();

                    using (SqlDataReader dataReader = command.ExecuteReader())
                    {
                        while (dataReader.Read())
                        {
                            Trade trade = new Trade
                            {
                                TradeId = dataReader["TradeId"].ToString(),
                                ISIN = dataReader["ISIN"].ToString(),
                                TradeDate = dataReader["TradeDate"].ToString(),
                                MaturityDate = dataReader["MaturityDate"].ToString(),
                                SchemeName = dataReader["SchemeName"].ToString(),
                                TradeType = dataReader["TradeType"].ToString(),
                                Currency = dataReader["Currency"].ToString(),
                                Amount = dataReader["Amount"].ToString()
                            };
                            trades.Add(trade);
                        }
                        sqlConnectionObject.Close();
                    }
                //}
            }
            catch (Exception ex)
            {
                throw new FXCalculatorException(ex.Message);
            }

            if (trades != null && trades.Count > 0)
            {
                foreach (var item in trades)
                {
                    FXRate fxRate = new FXRate();
                    fxRate.TradeId = item.TradeId;
                    fxRate.Currency = item.Currency;
                    fxRate.Amount = item.Amount;

                    if (item.Currency == "GBP")
                    {
                        fxRate.AppliedFXRate = "0.5";
                        fxRate.CalculatedFXRate = (Convert.ToInt64(fxRate.Amount) *
                                                    float.Parse(fxRate.AppliedFXRate)).ToString();
                    }
                    else if (item.Currency == "EUR")
                    {
                        fxRate.AppliedFXRate = "0.6";
                        fxRate.CalculatedFXRate = (Convert.ToInt64(fxRate.Amount) *
                                                    float.Parse(fxRate.AppliedFXRate)).ToString();
                    }
                    else if (item.Currency == "USD")
                    {
                        fxRate.AppliedFXRate = "0.7";
                        fxRate.CalculatedFXRate = (Convert.ToInt64(fxRate.Amount) *
                                                    float.Parse(fxRate.AppliedFXRate)).ToString();
                    }
                    else if (item.Currency == "INR")
                    {
                        fxRate.AppliedFXRate = "1";
                        fxRate.CalculatedFXRate = (Convert.ToInt64(fxRate.Amount) *
                                                    float.Parse(fxRate.AppliedFXRate)).ToString();
                    }
                    FxRates.Add(fxRate);
                }
            }
            return FxRates;
        }

        public bool SaveFXRate(List<FXRate> fxRates, SqlConnection sqlConnectionObject)
        {
            //Do your logic here to upload to DB table
            //Do not hardcode the connection string here
            //Do not create the redundant connection Object for SqlConnection, use the conncetionObject given in the method parameter.
            //Do not Prefix Database name in the SQL Query. Query should be "Insert into SBA.TableName"
            //Should not be "Insert into DatabaseName.SBA.TableName"
            var connectionstring = sqlConnectionObject.ConnectionString;
            if (fxRates != null & fxRates.Count > 0)
            {
                foreach (var rate in fxRates)
                {
                    try
                    {
                        using (sqlConnectionObject = new SqlConnection(connectionstring))
                        {
                            using (SqlCommand command = sqlConnectionObject.CreateCommand())
                            {
                                command.CommandText = @"INSERT INTO SBA.FX_Rate (TradeId, Currency, Amount, AppliedFXRate,
                                                        CalculatedFXRate)
                                                        VALUES (@TradeId, @Currency, @Amount, @AppliedFXRate,
                                                        @CalculatedFXRate)";
                                command.Parameters.AddWithValue("@TradeId", rate.TradeId);
                                command.Parameters.AddWithValue("@FxRate", rate.AppliedFXRate);
                                command.Parameters.AddWithValue("@CalculatedFXRate", rate.CalculatedFXRate);
                                command.Parameters.AddWithValue("@Currency", rate.Currency);
                                command.Parameters.AddWithValue("@Amount", rate.Amount);

                                sqlConnectionObject.Open();
                                command.ExecuteNonQuery();
                                sqlConnectionObject.Close();
                            }
                        }  
                    }
                    catch (Exception ex)
                    {
                        throw new FXCalculatorException(ex.Message);
                    }
                }
            }
            return true;
        }       
       
        public bool CopyToArchive(string sourcePathWithFileName, string targetPathWithFileName)
        {
            //Do your logic here
            //Do not hardcode the filename and the file path here
            string targetFile = sourcePathWithFileName + targetPathWithFileName;
            //string sourceFile = sourceFolder + FileName;

            try
            {
                if (!Directory.Exists(sourcePathWithFileName))
                {
                    Directory.CreateDirectory(sourcePathWithFileName);
                }
                //System.IO.File.Copy(sourceFile, targetFile, true);
            }
            catch (Exception ex)
            {
                throw new FXCalculatorException(ex.Message);
            }

            //File.Copy(sourcePathWithFileName + "\\" + targetPathWithFileName, true);
            return true;
        }
    }
}
