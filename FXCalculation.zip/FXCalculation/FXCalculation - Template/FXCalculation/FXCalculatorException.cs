﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FXCalculation
{
    public class FXCalculatorException:Exception
    {
        public FXCalculatorException () : base()
		{
		}

		public FXCalculatorException (string message) : base(message)
		{
		}

        public FXCalculatorException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }
}
