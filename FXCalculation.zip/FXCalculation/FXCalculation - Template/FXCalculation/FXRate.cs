﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FXCalculation
{
    public class FXRate
    {
        /*
         * Do not modify the return types of the below properties
         */
        public string TradeId { get; set; }        
        public string Currency { get; set; }
        public string Amount { get; set; }
        public string AppliedFXRate { get; set; }
        public string CalculatedFXRate { get; set; } 

    }
}
