﻿Imports System.Collections.Generic
Imports System.Data.SqlClient
Imports System.Data
Imports System.Collections

Public Class EmployeeValidator
    '        * Do not remove the attached TestProject. It is meant for auto evaluation of your source code.
    '        * Do not attach any test classess to the attached test project.
    '        * Do not attach any new test projects.
    '        * You are not required to write any automated test cases. You are supposed to write only the code.
    '  
    Public Sub ProcessData(ByVal xmlFilePath As String, ByVal xmlFileName As String, ByVal connection As SqlConnection)
        'Do your logic here
        'Step 1           
        'ReadAllEmployeesFromXmlFile
        'Step 2           
        'PickValidEmployees
        'Step 3
        'SaveValidEmployeesToDataBase           

    End Sub
    Public Function ReadAllEmployeesFromXmlFile(ByVal xmlFilePath As String, ByVal xmlFileName As String) As List(Of Employee)
        'Read the employee details from the xml file and return it in List collection
        'Do not hardcode the filename and the file path here

        'Do not return the date with time appended to it.

        Return Nothing
    End Function

    Public Function PickValidEmployees(ByVal employees As List(Of Employee)) As List(Of Employee)
        'Pick the valid employees from the List collection
        'Return the valid employees in a List

        Return Nothing
        'Return only valid employees in List
    End Function

    Public Sub SaveValidEmployeesToDB(ByVal employees As List(Of Employee), ByVal connection As SqlConnection)
        'Do not Prefix Database name in the SQL Query. Query should be "Insert into SBA.TableName"
        'Should not be "Insert into DatabaseName.SBA.TableName"
        'Do not hardcode the connection string here
    End Sub


End Class
