﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DotnetFramework
{
    public class Constants
    {
        public string strInptextfileFodlerPath = @"D:\RDP\Input\";
        public string strInptextfileName = @"Trade.txt";
        public string strOuttextfileFolderPath = @"D:\RDP\Output\";
        public string strOuttextfileName = @"Trade.txt";
        public string strOutNonValidtextfileName = @"NonValidTrade.txt";
        public string strInpXMLfileFolderPath = @"D:\RDP\Input\";
        public string strInpXMLfileName = @"Trade.xml";
        public string strOutXMLfileFolderPath = @"D:\RDP\Output\";
        public string strOutXMLfileName = @"Trade.xml";
        public string strOutXMLfileNamewithCalcAmount = @"TradeCalculatedCol.xml";
        public string strDBConnectionstring = @"Data Source=CTSINTBMVMGAS1\SQL,1435;Initial Catalog=MSAS_CLS_DEV_AUGABM_REL;Integrated Security=True";
    }
}
