﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

namespace DotnetFramework
{
    public class MyDatabase : DataContext 
    {
        public MyDatabase()
            : base(@"Data Source=CTSINTBMVMGAS1\SQL,1435;Initial Catalog=MSAS_CLS_DEV_AUGABM_REL;Integrated Security=True")
        {
        }
    }
}
