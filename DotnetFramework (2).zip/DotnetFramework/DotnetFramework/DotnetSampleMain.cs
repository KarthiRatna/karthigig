﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DotnetFramework
{
    class DotnetSampleMain   
    {
        static void Main(string[] args)
        {
            //string s = "I am a good girl";
            //char[] arr = s.ToCharArray();
            //Array.Reverse(arr);
            //Console.WriteLine(new String(arr));

            //Console.ReadLine();
            Constants cns = new Constants();
            FileOperations flOper = new FileOperations();
            List<Trade> trades = new List<Trade>();
            List<Trade> validtrades = new List<Trade>();
            trades = flOper.ReadTextFile(cns.strInptextfileFodlerPath, cns.strInptextfileName);
            validtrades = flOper.GetValiadtedTrades(trades);
            flOper.SaveitinXML(cns.strOutXMLfileFolderPath, cns.strOutXMLfileName, validtrades);
            List<Trade> tradesfromXML = new List<Trade>();
            tradesfromXML = flOper.ReadnXML(cns.strInpXMLfileFolderPath, cns.strInpXMLfileName);
            List<Trade> tradesfromXMLwithLinq = new List<Trade>();
            tradesfromXMLwithLinq = flOper.ReadnXMLWithLinq(cns.strInpXMLfileFolderPath, cns.strInpXMLfileName);
            flOper.SaveitinXMLwithCalculatedColumn(cns.strOutXMLfileFolderPath, cns.strOutXMLfileNamewithCalcAmount, validtrades);            
            

            flOper.SaveitinText(cns.strOuttextfileFolderPath, cns.strOuttextfileName, validtrades);
            List<Trade> nonValidTrades = new List<Trade>();
            nonValidTrades = (from tr in trades
                              where !(from vtr in validtrades select vtr.TradeId).Contains(tr.TradeId)
                              select tr).ToList();
            flOper.SaveitinText(cns.strOuttextfileFolderPath, cns.strOutNonValidtextfileName, nonValidTrades);
            flOper.SaveitinDB(cns.strDBConnectionstring, validtrades);
            flOper.SaveitinDBWithLinq(validtrades);
            List<Trade> tradeswithlingfromdb = new List<Trade>();
            tradeswithlingfromdb = flOper.ReadFromDB(cns.strDBConnectionstring);


            Console.ReadLine();


            
        }
    }
}
