﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Xml.Serialization;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Data;

namespace DotnetFramework
{
    class FileOperations
    {
        public List<Trade> ReadTextFile(string TextFileFolderPath, string TextFileName)
        {
            List<Trade> trades = new List<Trade>();
            var tradedata = File.ReadAllLines(TextFileFolderPath + TextFileName);
            foreach (var lines in tradedata)
            {
                string[] _tradearray = lines.Split(',');
                trades.Add(new Trade()
                {
                    TradeId = _tradearray[0],
                    ISIN = _tradearray[1],
                    TradeDate = _tradearray[2],
                    MaturityDate = _tradearray[3],
                    Currency = _tradearray[4],
                    Amount = _tradearray[5]
                });

            }
            return trades;
        }
        public List<Trade> GetValiadtedTrades(List<Trade> trades)
        {
            List<Trade> validtrades = new List<Trade>();
            Regex rgxtradeid = new Regex(@"\bTR\d{3}\b");
            Regex rgxISIN = new Regex(@"\bISIN\d+\b");
            //bool IsSuccess = true;
            DateTime tradeDate;
            DateTime maturityDate;
            decimal decAmount;
            validtrades = trades.
                Where(item => !string.IsNullOrEmpty(item.TradeId) && rgxtradeid.IsMatch(item.TradeId) &&
                    !string.IsNullOrEmpty(item.ISIN) && rgxISIN.IsMatch(item.ISIN) &&
                    !string.IsNullOrEmpty(item.TradeDate) && DateTime.TryParseExact(item.TradeDate, "mm-dd-yyyy", null, DateTimeStyles.None, out tradeDate) &&
                    !string.IsNullOrEmpty(item.Currency) && item.Currency.Length == 3 &&
                    !string.IsNullOrEmpty(item.Amount) && decimal.TryParse(item.Amount, out decAmount) &&
                    DateTime.TryParseExact(item.MaturityDate, "mm-dd-yyyy", null, DateTimeStyles.None, out maturityDate) &&
                    maturityDate > tradeDate && maturityDate <= tradeDate.AddYears(3)).ToList();
            
                             

            //foreach (var trade in trades)
            //{
            //    IsSuccess = true;
            //    if (trade.TradeId == null || !rgxtradeid.IsMatch(trade.TradeId))
            //    {
            //        IsSuccess = false;
            //    }
            //    else if (trade.ISIN == null || !rgxISIN.IsMatch(trade.ISIN))
            //    {
            //        IsSuccess = false;
            //    }
            //    else if (trade.TradeDate == null || !DateTime.TryParseExact(trade.TradeDate, "mm-dd-yyyy", null, DateTimeStyles.None, out tradeDate))
            //    {
            //        IsSuccess = false;
            //    }
            //    else if (trade.Currency == null || trade.Currency.Length != 3)
            //    {
            //        IsSuccess = false;
            //    }
            //    else if (trade.Amount == null || !decimal.TryParse(trade.Amount, out decAmount))
            //    {
            //        IsSuccess = false;
            //    }
            //    else if (!DateTime.TryParseExact(trade.MaturityDate, "mm-dd-yyyy", null, DateTimeStyles.None, out maturityDate))
            //    {
            //        IsSuccess = false;
            //    }
            //    else if (maturityDate < tradeDate || maturityDate > tradeDate.AddYears(3))
            //    {
            //        IsSuccess = false;
            //    }
            //    if (IsSuccess)
            //    {
            //        validtrades.Add(trade);
            //    }
            //}
            return validtrades;

            //validatedtrades = trades.Where(item => item.ISIN != null && rgxISIN.IsMatch(item.ISIN) && item.TradeId != null && rgxtradeid.IsMatch(item.TradeId)).Select(s => s).ToList();
            //return validatedtrades;
        }
        public void SaveitinXML(string XMLFileFolderPath, string XMLFileName, List<Trade> trades)
        {
            XmlSerializer xs = new XmlSerializer(typeof(List<Trade>));
            
            StreamWriter sw = new StreamWriter(XMLFileFolderPath + XMLFileName);
            xs.Serialize(sw, trades);
            sw.Close();
            sw.Dispose();
        }
        public List<Trade> ReadnXML(string XMLFileFolderPath, string XMLFileName)
        {
            List<Trade> trades = new List<Trade>();
            XmlSerializer xs = new XmlSerializer(typeof(List<Trade>));
            StreamReader sr = new StreamReader(XMLFileFolderPath + XMLFileName);
            trades = (List<Trade>)xs.Deserialize(sr);
            sr.Close();
            sr.Dispose();
            return trades;
        }
        public List<Trade> ReadnXMLWithLinq(string XMLFileFolderPath, string XMLFileName)
        {
            List<Trade> trades = new List<Trade>();
            XDocument xdoc = new XDocument();
            
            return trades;
        }
        public void SaveitinXMLwithCalculatedColumn(string XMLFileFolderPath, string XMLFileName, List<Trade> trades)
        {
            XDocument xdoc = new XDocument();
            XElement xtrades = new XElement("Trades");
            foreach (Trade tr in trades)
            {
                xtrades.Add(new XElement("Trade",
                    new XElement("TradeId", tr.TradeId),
                    new XElement("ISIN", tr.ISIN),
                    new XElement("TradeDate",tr.TradeDate),
                    new XElement("MaturityDate", tr.MaturityDate),
                    new XElement("Currency",tr.Currency),
                    new XElement("Amount",tr.Amount),
                    new XElement("CalculatedAmount", CalculateConvertedAmount(Convert.ToDecimal(tr.Amount) , tr.Currency))));
            }
            xdoc.Add(xtrades);
            xdoc.Save(XMLFileFolderPath + XMLFileName);
        }
        public Decimal CalculateConvertedAmount(Decimal Amount, string Currency)
        {
            Decimal CalculatedAmount;
            switch (Currency)
            {
                case "USD": return Decimal.Multiply(Amount , Convert.ToDecimal(0.6));
                case "EUR": return Decimal.Multiply(Amount , Convert.ToDecimal(0.1));
                case "IND": return Decimal.Multiply(Amount , Convert.ToDecimal(1));
                default: return 0;
            }

        }
        public void SaveitinText(string TextFileFolderPath, string TextFileName, List<Trade> trades)
        {
            FileStream fs = new FileStream(TextFileFolderPath + TextFileName, FileMode.Create, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);
            foreach (Trade tr in trades)
            {
                string[] tradesarr = new string[6]; ;
                tradesarr[0] = tr.TradeId;
                tradesarr[1] = tr.ISIN;
                tradesarr[2] = tr.TradeDate;
                tradesarr[3] = tr.MaturityDate;
                tradesarr[4] = tr.Currency;
                tradesarr[5] = tr.Amount;

                string tradeline = tradesarr[0] + "," + tradesarr[1] + "," + tradesarr[2] + "," + tradesarr[3] + "," + tradesarr[4] + "," + tradesarr[5];                
                sw.WriteLine(tradeline);
                
            }
            sw.Close();
            sw.Dispose();
            fs.Close();
            fs.Dispose();
        }
        public void SaveitinDB(string DBConnstring, List<Trade> trades)
        {
            foreach (Trade trade in trades)
            {
                SqlConnection con = new SqlConnection(DBConnstring);
                con.Open();
                SqlCommand com = new SqlCommand("Insert into Trades values ('" + trade.TradeId + "','" +
                    trade.ISIN + "','" +
                    Convert.ToDateTime(trade.TradeDate)  + "','" +
                    Convert.ToDateTime(trade.MaturityDate)  + "','" +
                    trade.Currency + "'," +
                    Convert.ToDecimal(trade.Amount)  + ")" ,con
                    );
                
                com.ExecuteNonQuery();
                con.Close();
                com.Dispose();

            }
        }
        public void SaveitinDBWithLinq(List<Trade> trades)
        {
            MyDatabase mydb = new MyDatabase();
            foreach (Trade trade in trades)
            {
                mydb.ExecuteCommand("Insert into Trades values ('" + trade.TradeId + "','" +
                        trade.ISIN + "','" +
                        Convert.ToDateTime(trade.TradeDate) + "','" +
                        Convert.ToDateTime(trade.MaturityDate) + "','" +
                        trade.Currency + "'," +
                        Convert.ToDecimal(trade.Amount) + ")"
                        );
            }
              
        }
        public List<Trade> ReadFromDB(String StrDBConn)
        {
            SqlConnection sqlcon = new SqlConnection(StrDBConn);
            SqlCommand com = new SqlCommand("Select * from Trades", sqlcon );
            sqlcon.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(com);
            SqlCommandBuilder combuil = new SqlCommandBuilder();
            combuil.DataAdapter = adapter;
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            List<Trade> trades = new List<Trade>();
            foreach (DataRow dr in dt.Rows )
            {
                Trade trade = new Trade();
                trade.TradeId = dr[0].ToString();
                trade.ISIN = dr[1].ToString();
                trade.TradeDate = dr[2].ToString();
                trade.MaturityDate = dr[3].ToString();
                trade.Currency = dr[4].ToString();
                trade.Amount = dr[5].ToString();
                trades.Add(trade);
            }
            return trades;


        }

        
    }
}
