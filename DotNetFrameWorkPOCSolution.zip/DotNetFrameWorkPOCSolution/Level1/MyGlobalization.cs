﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Globalization;

namespace Level1
{
    public class MyGlobalization
    {
        private double salary { get; set; }
        private string culture { get; set; }
        private DateTime date { get; set; }
        public void SetSalary()
        {
            Console.Write("\n Enter the salary amount : ");
            this.salary = double.Parse(Console.ReadLine());
        }

        public void SetCulture()
        {
            Console.Write("\n Enter the culture : Eg: en-US, ru-RU, ja-JP:  ");
            this.culture = Console.ReadLine();
        }

        public void SetDate()
        {
            Console.Write("\n Enter the date in mm/dd/yyyy or yyyy/mm/dd format : ");
            this.date = DateTime.Parse(Console.ReadLine());
        }


        public static void GetCultureDetails()
        {
            MyGlobalization myGlobalization = new MyGlobalization();
            myGlobalization.SetCulture();
            myGlobalization.SetSalary();
            myGlobalization.SetDate();
            Thread.CurrentThread.CurrentCulture = new CultureInfo(myGlobalization.culture);
            Console.WriteLine("\n orignal salary " + myGlobalization.salary);
            Console.WriteLine("culture specific salary : " + myGlobalization.salary.ToString("c"));
            Console.WriteLine("culture specific Date : " + myGlobalization.date.ToShortDateString());
            Console.ReadLine();

        }

        public static void GetCultureRegionDetails()
        {
            MyGlobalization myGlobalization = new MyGlobalization();
            myGlobalization.SetCulture();
            CultureInfo myCIintl = new CultureInfo(myGlobalization.culture, false);
            Console.WriteLine("{0,-33}{1,-25}", "PROPERTY", "INTERNATIONAL");
            Console.WriteLine("{0,-33}{1,-25}", "CompareInfo", myCIintl.CompareInfo);
            Console.WriteLine("{0,-33}{1,-25}", "DisplayName", myCIintl.DisplayName);
            Console.WriteLine("{0,-33}{1,-25}", "EnglishName", myCIintl.EnglishName);
            Console.WriteLine("{0,-33}{1,-25}", "IsNeutralCulture", myCIintl.IsNeutralCulture);
            Console.WriteLine("{0,-33}{1,-25}", "IsReadOnly", myCIintl.IsReadOnly);
            Console.WriteLine("{0,-33}{1,-25}", "LCID", myCIintl.LCID);
            Console.WriteLine("{0,-33}{1,-25}", "Name", myCIintl.Name);
            Console.WriteLine("{0,-33}{1,-25}", "NativeName", myCIintl.NativeName);
            Console.WriteLine("{0,-33}{1,-25}", "Parent", myCIintl.Parent);
            Console.WriteLine("{0,-33}{1,-25}", "TextInfo", myCIintl.TextInfo);
            Console.WriteLine("{0,-33}{1,-25}", "ThreeLetterISOLanguageName", myCIintl.ThreeLetterISOLanguageName);
            Console.WriteLine("{0,-33}{1,-25}", "ThreeLetterWindowsLanguageName", myCIintl.ThreeLetterWindowsLanguageName);
            Console.WriteLine("{0,-33}{1,-25}", "TwoLetterISOLanguageName", myCIintl.TwoLetterISOLanguageName);
            Console.WriteLine("{0,-33}{1,-25}", "CurrencySymbol", myCIintl.NumberFormat.CurrencySymbol);
            Console.WriteLine("{0,-33}{1,-25}", "ISOCurrencySymbol", new RegionInfo(myCIintl.LCID).ISOCurrencySymbol);


            Console.WriteLine();

        }


    }
}
