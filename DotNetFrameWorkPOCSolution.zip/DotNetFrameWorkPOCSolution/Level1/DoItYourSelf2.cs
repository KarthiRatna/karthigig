﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace Level1
{
    public class DoItYourSelf2
    {

        public void Task1()
        {
            Console.WriteLine("Dictionary - Key & Value pair to Collection");
            Dictionary<string, string> dicNumber = new Dictionary<string, string>();
            dicNumber.Add("1", "First");
            dicNumber.Add("2", "Second");
            dicNumber.Add("3", "Third");
           string value = dicNumber["1"];
            List<KeyValuePair<string, string>> listDictData = dicNumber.ToList();
            foreach (var item in listDictData)
            {
                Console.WriteLine("Key {0}, Pair{1}", item.Key, item.Value);
            }
            Console.WriteLine("Dictionary - Key to Collection");
            List<string> listDictKey = dicNumber.Keys.ToList();
            foreach (var item in listDictKey)
            {
                Console.WriteLine("Key {0}", item);
            }

        }

        public void Task2()
        {
            Console.WriteLine("Insert Values into Dictionary - Key & Value");
            Dictionary<int, string> dictKeyValues = new Dictionary<int, string>();
            dictKeyValues.Add(-1, "iguana");
            dictKeyValues.Add(0, "llama");
            dictKeyValues.Add(1, "dog");
            dictKeyValues.Add(2, "Cat");

            foreach (var item in dictKeyValues)
            {
                Console.WriteLine("Key {0}, Pair{1}", item.Key, item.Value);
            }
        }

        public void Task3()
        {
            Console.WriteLine("Insert Values into HashTable - Key & Value");
            Hashtable hshTbl = new Hashtable();
            hshTbl.Add("first", 1);
            hshTbl.Add("Second", "Vivi");
            hshTbl.Add(3, "!");
            foreach (DictionaryEntry item in hshTbl)
            {
                Console.WriteLine("Key {0}, Value {1}", item.Key, item.Value);
            }

        }

        public void Task4()
        {

            string inputString = "1-One,2-Tw0,3-Three";
            Array parseArray = inputString.Split(',');
            Dictionary<string, string> dictValue = new Dictionary<string, string>();
            foreach (var item in parseArray)
            {
                string[] splitvalue = item.ToString().Split('-');
                dictValue.Add(splitvalue[0].ToString(), splitvalue[1].ToString());
            }
            foreach (var item in dictValue)
            {
                Console.WriteLine("Key {0}, Value {1}", item.Key, item.Value);
            }
        }
    }
}
