﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;

namespace Level1
{
    public class MyDataBase : DataContext
    {

        public MyDataBase()
            : base(@"Data Source=CTSINTBMVMGAS1\SQL,1435;Initial Catalog=master;Integrated Security=True")
        {

        }

        //  public Table<Trade> tradClass;

    }
}
