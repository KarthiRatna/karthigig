﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using StringOperations;

namespace Level1
{
    class Program
    {
        public static void Main()
        {
            Sample();

            //Overloading, Overriding, Property Get & Set
            //   Exercise objExercise = new Exercise();
            //  Exercise.CircleMain();
            // If Else Statement
            //Employee objEmployee = new Employee();
            //    Employee.EmployeeMain();

            //Console.WriteLine("Level 1 Session");
            //Console.ReadLine();
            //Console.WriteLine("Enter Any Key to Start Session");
            ////DoITYourSelf1
            //DoItYourSelf1 objDITUrSlf1 = new DoItYourSelf1();
            //objDITUrSlf1.Task1();

            //objDITUrSlf1.Task2();

            //objDITUrSlf1.Task3();
            //objDITUrSlf1.Task4();
            //Generics objGenerics = new Generics();
            //objGenerics.Task1();

            //ArrayListSamples listSample = new ArrayListSamples();
            //DoItYourSelf2 objDoItYourSelf2 = new DoItYourSelf2();
            //objDoItYourSelf2.Task1();
            //objDoItYourSelf2.Task2();
            //objDoItYourSelf2.Task3();
            //objDoItYourSelf2.Task4();


            FileOperations flStrm = new FileOperations();
            //flStrm.WriteData();
            //flStrm.ReadCharacterFile();
            List<Trade> tradeData = flStrm.GetTradeData(@"D:\Learning\Learning\DotNetFrameWork\InBound\", "TestFile.txt");
            tradeData = flStrm.VaildateTrade(tradeData);
            flStrm.WriteTradeXML(tradeData, @"D:\Learning\Learning\DotNetFrameWork\OutBound\", "Trade.xml");
            tradeData = new List<Trade>();
            tradeData = flStrm.ReadTradeXML(@"D:\Learning\Learning\DotNetFrameWork\OutBound\", "Trade.xml");
            flStrm.CreateCaculatedTrade(tradeData, @"D:\Learning\Learning\DotNetFrameWork\OutBound\", "Report.xml");
            //  flStrm.SaveTrades(tradeData);
            flStrm.SaveTradesWithLinQ(tradeData);
            //   flStrm.ReplaceCharacter();
            //flStrm.CountOfWord();
            //flStrm.CountOfEachCharacters();
            //flStrm.CountofWordinEachline();

            #region RegEx

            RegExpressionSample regExp = new RegExpressionSample();


            //regExp.ValidateAllEmailId();
            // regExp.StartAndEndMatch();
            //regExp.ValidateMobileNumber();
            //regExp.GetProtocolAndPort();
            //regExp.GetSubstringWithRegEx();
            // regExp.ValidatePositiveValue();
            //regExp.ValidateNumeric();

            #endregion

            #region XMLSerialization

            //Vehicle vhl = SerializationSamples.GetVehicleDetails(new Vehicle());
            //SerializationSamples.SerializeToXml(vhl);
            // ShoppingMall mall = SerializationSamples.GetShoppingMallDetails(new ShoppingMall());
            //SerializationSamples.SerializeToSoapFormatted(mall);
            //SerializationSamples.GetDeserialize();

            #endregion

            #region Globalization
            //MyGlobalization.GetCultureDetails();
            //  MyGlobalization.GetCultureRegionDetails();
            #endregion
            Console.WriteLine("Enter Any Key to End Session");
            Console.ReadLine();


        }


        public static void Sample()
        {
            var test = "test".Reverse();
            //Structs & Enum
            dineshStructs objStructs = new dineshStructs(1, "Vivi", "Learning and Development", dineshStructs.Genders.Male, "test");
            Console.WriteLine(objStructs.intEmployeedId);
            //String Operation
            StringOperate objStringOperation = new StringOperate();
            //Replace
            string content = "This is some text to search";
            Console.WriteLine("string before replace " + content);
            Console.WriteLine("string after replace " + objStringOperation.ReplaceString(content, "search", "replace"));
            //Length of a string 
            Console.WriteLine("Length of string: " + objStringOperation.GetLengthOfString(content).ToString());
            //String Reverse
            Console.WriteLine("String Reverse: " + objStringOperation.GetStringReverse(content));
            //Extract string
            Console.WriteLine("String extract: " + objStringOperation.GetSubString(content));
            //Extract string
            Console.WriteLine("String Remove: " + objStringOperation.RemoveString(content, "text"));
            //Insert String
            Console.WriteLine("String Insert: " + objStringOperation.InsertString(content, "Test"));
            Console.WriteLine("Remove White spaces: " + "       Test    ".Trim());
            Console.WriteLine("Add White space begin: " + "Test".PadLeft(5, ' ') + ".");
            Console.WriteLine("Add White space end: " + "Test".PadRight(5, ' ') + ".");
            Console.WriteLine("Add White space begin: " + string.Format("{0,10}", "£1.00") + ".");
            Console.WriteLine("Add White space begin: " + string.Format("{0,10}", "£10.00") + ".");
            Console.WriteLine("Add White space begin: " + string.Format("{0,10}", "£100.00") + ".");
            Console.WriteLine("Add White space begin: " + string.Format("{0,-10}", "£1.00") + ".");
            Console.WriteLine("Add White space begin: " + string.Format("{0,-10}", "£10.00") + ".");
            Console.WriteLine("Add White space begin: " + string.Format("{0,-10}", "£100.00") + ".");

            Console.ReadKey();


        }
    }




}
