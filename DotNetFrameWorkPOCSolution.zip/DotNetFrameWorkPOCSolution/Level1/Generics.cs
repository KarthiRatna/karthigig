﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Level1
{
    public class Generics
    {
        public Generics()
        {
            Console.WriteLine("Do it yourself Generic,Collections & Dictionary");
        }

        public void Task1()
        {
            Console.WriteLine("Maximum of {0}, {1} and {2} is {3}\n", 3, 4, 5, Maximum(3, 4, 5));
            Console.WriteLine("Maximum of {0}, {1} and {2} is {3}\n", 6.6, 8.8, 7.7, Maximum(6.6, 8.8, 7.7));
            Console.WriteLine("Maximum of {0}, {1} and {2} is {3}\n", "pear1", "pear2", "pear3",
            Maximum("pear1", "pear2", "pear3"));
            Console.WriteLine("Maximum of {0}, {1} and {2} is {3}\n", 1, 3, 3.3, Maximum(1, 3, 3.3));
            int value1 = 1;
            int value2 = 2;
            Console.WriteLine("Swap int Values 1 and 2: " + SwapValues(ref value1, ref value2).ToString());
            GetSwapValues();
            Console.ReadLine();
        } // end Main

        // generic function determines the
        // largest of the IComparable objects
        private static T Maximum<T>(T x, T y, T z)
            where T : IComparable<T>
        {

            T max = x; // assume x is initially the largest

            // compare y with max
            if (y.CompareTo(max) > 0)
                max = y; // y is the largest so far

            // compare z with max
            if (z.CompareTo(max) > 0)
                max = z; // z is the largest

            return max; // return largest object
        } // end method Maximum

        public T SwapValues<T>(ref T value1, ref T value2)
        {
            T park;
            park = value1;
            value1 = value2;
            value2 = park;
            // return string.Format("Swapped values {0} and {1}", value1, value2);
            return value1;
        }

        public void GetSwapValues()
        {
            int x = 1;
            int y = 2;
            int result = SwapValues<int>(ref x, ref y);
            string value1 = "jagan";
            string value2 = "Dinesh";
            string resultString = SwapValues<string>(ref value1, ref value2);
        }



    }

}
