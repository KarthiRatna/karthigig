﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Level1
{
    //class Program
    //{
    //    //static void Main(string[] args)
    //    //{
    //    //    Circle c = new Circle();
    //    //    Sphere s = new Sphere();

    //    //    c.Radius = 20.25;
    //    //    Exercise.Show(c);

    //    //    s.Radius = 20.25;
    //    //    Exercise.Show(s);


    //    //}


    //}

    class Circle
    {
        public int MyProperty1 { get; set; }

        private double _radius;
        public double Radius
        {
            get { return (_radius < 0) ? 0.00 : _radius; }
            set { _radius = value; }
        }
        public double Diameter
        {
            get { return Radius * 2; }
        }
        public double Circumference
        {
            get { return Diameter * 3.14159; }
        }
        public double Area
        {
            get { return Radius * Radius * 3.14159; }
        }

    }

    class Sphere : Circle
    {
        new public double Area
        {
            get { return 4 * Radius * Radius * 3.14159; }
        }

        public double Volume
        {
            get { return 4 * 3.14159 * Radius * Radius * Radius / 3; }
        }

    }

    public class Exercise
    {


        static void Show(Circle round)
        {
            Console.WriteLine("Circle Characteristics");
            Console.WriteLine("Side:     {0}", round.Radius);
            Console.WriteLine("Diameter: {0}", round.Diameter);
            Console.WriteLine("Circumference: {0}", round.Circumference);
            Console.WriteLine("Area:     {0}", round.Area);
        }

        static void Show(Sphere ball)
        {
            Console.WriteLine("\nSphere Characteristics");
            Console.WriteLine("Side:     {0}", ball.Radius);
            Console.WriteLine("Diameter: {0}", ball.Diameter);
            Console.WriteLine("Circumference: {0}", ball.Circumference);
            Console.WriteLine("Area:     {0}", ball.Area);
            Console.WriteLine("Volume: {0}\n", ball.Volume);
            Console.ReadLine();
        }

        // public static void Main()
        public static void CircleMain()
        {
            Circle c = new Circle();
            Sphere s = new Sphere();

            c.Radius = 20.25;
            Show(c);

            s.Radius = 20.25;
            Show(s);

            // return 0;
        }

    }


}
