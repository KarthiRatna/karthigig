﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StringOperations
{
    public struct dineshStructs
    {

        public int intEmployeedId;
        public string strEmployeeName;
        public string strEmployeeDept;
        private string test;
        //Enum Values
        public enum Genders { Male = 6, Female };

        public Genders gender;
        public dineshStructs(int _intEmployeeId, string _strEmployeeName, string _strEmployeeDept, Genders _gender,
            string _test
            )
        {
            intEmployeedId = _intEmployeeId;
            strEmployeeName = _strEmployeeName;
            strEmployeeDept = _strEmployeeDept;
            gender = _gender;
            test = _test;
        }

        public override string ToString()
        {
            return string.Format("EmployeeId: {0}, EmployeeName: {1}, EmployeeDept: {2}, Mr or Mrs: {3} {4}",
                intEmployeedId, strEmployeeName, strEmployeeDept, gender, (int)Genders.Female);
        }

    }

}
