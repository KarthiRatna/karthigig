﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Level1
{
    public class DoItYourSelf1
    {
        #region  Task 1

        public void Task1()
        {
            Console.WriteLine("Please Enter the Text: ");
            string s = Console.ReadLine();
            Console.WriteLine("User Input:" + s);
            Console.ReadKey();
        }

        #endregion

        #region Task 2

        public double Principal { get; set; }
        public Double RateofInterest { get; set; }
        public Double NoOfYears { get; set; }
        public Double _simpleInterest;
        public Double SimpleInterest
        {
            get
            {
                _simpleInterest = (Principal * RateofInterest * NoOfYears) / 100;
                return _simpleInterest;
            }
            set { value = _simpleInterest; }
        }
        public double Task2()
        {
            Console.WriteLine("Please Enter the Principal Values(In Numeric): ");
            Principal = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Please Enter the Rate of Interest Values(In Numeric): ");
            RateofInterest = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Please Enter the No Of Years(In Numeric): ");
            NoOfYears = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Simple Interest:  " + SimpleInterest.ToString());
            return SimpleInterest;
        }

        #endregion

        #region Task 3

        public void Task3()
        {

            Console.WriteLine("Enter the Number of Items: ");
            int CountOfProducts = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(GetAndCreateProductDetails(CountOfProducts).ToString());
        }

        public string GetAndCreateProductDetails(int CountOfProducts)
        {
            StringBuilder productDetails = new StringBuilder();
            productDetails.Append("ProductId\tProductName\tThe PurchaseQuantity\tBillRate\n");
            double price, totalPrice;
            price = totalPrice = 0.00;
            double quantity = 0.00;
            for (int i = 0; i < CountOfProducts; i++)
            {
                Console.WriteLine("Enter the ProductID: ");
                productDetails.Append(Console.ReadLine() + "\t");
                Console.WriteLine("Enter the ProdName: ");
                productDetails.Append(Console.ReadLine() + "\t");
                Console.WriteLine("Enter the ProductQuantity: ");
                quantity = Convert.ToDouble(Console.ReadLine());
                productDetails.Append(quantity + "\t");
                Console.WriteLine("Enter the Price: ");
                price = Convert.ToDouble(Console.ReadLine());
                totalPrice += price * quantity;
                productDetails.Append(price + "\t\n");

            }
            productDetails.Append("Total Price is " + totalPrice);
            return productDetails.ToString();
        }

        #endregion

        #region Task 4

        public void Task4()
        {


            Console.WriteLine("Enter the Train Details Train No., Train Name and Ticket Available");
            string trainNumber = Console.ReadLine();
            string trainName = Console.ReadLine();
            int totalSeatsAvailable = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Traing number: ");
            if (Console.ReadLine() != trainNumber)
                Console.WriteLine("No Sucn Train Available");
            else
            {
                Console.WriteLine("Seats Available is " + totalSeatsAvailable);
                Console.WriteLine("Enter Number of Seats to Book ");
                int seatsToBook = Convert.ToInt32(Console.ReadLine());
                if (seatsToBook > totalSeatsAvailable)
                {
                    Console.WriteLine("Very limited seats to available, you cant book the ticket");
                }
                else
                {
                    Console.WriteLine("The Traing Number : " + trainNumber);
                    Console.WriteLine("The Traing Name : " + trainNumber);
                    Console.WriteLine("The seat booked : " + seatsToBook);
                    Console.WriteLine("After booking seat available " + (totalSeatsAvailable - seatsToBook).ToString());
                }
            }

        }
        #endregion
    }
}
