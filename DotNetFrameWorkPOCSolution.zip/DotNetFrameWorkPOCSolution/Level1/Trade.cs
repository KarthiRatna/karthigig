﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace Level1
{
    [XmlRoot("Trades")]
    public class Trade
    {
        public string TradeId;
        public string ISIN, TradeDate, MaturityDate, Currency, Amount;


    }
}
