﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace Level1
{
    public class RegExpressionSample
    {
        public void ValidateAllEmailId()
        {
            Console.WriteLine("Please Enter Email Id: ");
            string emailId = Console.ReadLine();
            ValidateEmailId(emailId);
            ValidateTypeEmailId(emailId);
        }

        public void ValidateEmailId(string emailId)
        {

            if (Regex.IsMatch(emailId, @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$", RegexOptions.IgnoreCase))
                Console.WriteLine("Valid Email Id");
            else
                Console.WriteLine("Invalid Email Id");


        }


        public void ValidateTypeEmailId(string emailId)
        {
            if (Regex.IsMatch(emailId,
                       @"^(?("")("".+?(?<!\\)""@)|(([0-9a-z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-z])@))" +
                       @"(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-z][-\w]*[0-9a-z]*\.)+[a-z0-9][\-a-z0-9]{0,22}[a-z0-9]))$",
                       RegexOptions.IgnoreCase))
                Console.WriteLine("Valid Email Id");
            else
                Console.WriteLine("Invalid Email Id");


        }

        public void StartAndEndMatch()
        {
            string str = "make maze and manage to measure it, Manage";
            MatchCollection mc = Regex.Matches(str, @"\bm\S*e\b");
            Console.WriteLine("Matched String starts with m and e");
            foreach (var item in mc)
            {
                Console.WriteLine(item.ToString());
            }


        }

        public void ValidateMobileNumber()
        {
            Console.WriteLine("Please Enter Mobile Number");
            string mobileNumber = Console.ReadLine();
            if (ValidateNumeric(mobileNumber))
                if (ValidateTwelveDigits(mobileNumber))
                    ValidateIndianMobile(mobileNumber);
                else
                    Console.WriteLine("Mobile Number Should be 12 digit");
            else
                Console.WriteLine("Mobile Number Should be numeric");
        }


        public void ValidateIndianMobile(string mobileNumber)
        {
            string mobilePattern = @"\b[91]{2}[7-9]{1}\d{9}\b";
            if (Regex.IsMatch(mobileNumber, mobilePattern))
                Console.WriteLine("Valid Mobile Number");
            else
                Console.WriteLine("Mobile Number should starts with 91");
        }

        public bool ValidateNumeric(string mobileNumber)
        {
            string numericPattern = @"\b\d+\b";
            return Regex.IsMatch(mobileNumber, numericPattern);
        }

        public bool ValidateTwelveDigits(string mobileNumber)
        {
            string numericPattern = @"\b\d{12}\b";
            return Regex.IsMatch(mobileNumber, numericPattern);
        }

        public void GetProtocolAndPort()
        {
            string url = "https://onecognizant.cognizant.com:8080/";
            string portNumber = Regex.Match(url, @"\b\d+\b").ToString();
            string protocol = Regex.Match(url, @"^(?:(ht|f)tp(s?)\:)?").ToString();

            Console.WriteLine(protocol + portNumber);
        }

        public void GetSubstringWithRegEx()
        {
            string subStringPattern = "\'(.*?)\'";
            string value = "name='40474740-1e40-47ce-aeba-ebd1eb1630c0'";
            string subString = Regex.Match(value, subStringPattern).ToString();
            Console.WriteLine("SubString Value " + subString);
        }

        public void ValidatePositiveValue()
        {
            string positivePattern = @"\b-?[0-9]\d*(\.\d+)?\b";
            Console.WriteLine("Please Enter postive Integer");
            string positiveValue = Console.ReadLine();
            if (Regex.IsMatch(positiveValue, positivePattern))
            {
                Console.WriteLine("Valid integer values");
            }
            else
            {
                Console.WriteLine("Not a Positive Value");
            }
        }

        public void ValidateNumeric()
        {
            Console.WriteLine("Enter a valid integer value");
            string enteredValue = Console.ReadLine();
            decimal outputValue;
            if (decimal.TryParse(enteredValue, out outputValue) == true)
                Console.WriteLine("Valid Integer Value");
            if (outputValue > 0)
                Console.WriteLine("Valid Positive Value");
            else
                Console.WriteLine("Not a Positive Value");
        }

    }
}
