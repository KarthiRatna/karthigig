﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Level1
{
    class Employee
    {
        int Empno { get; set; }
        string Name { get; set; }
        string Designation { get; set; }
        int Basic { get; set; }
        int Allowance { get; set; }
        int Deduction { get; set; }
        double NetPay { get; set; }
        Char Grade { get; set; }

        public void ShowDetails()
        {
            Console.WriteLine("Employee Number : {0}", Empno);
            Console.WriteLine("Employee Name : {0}", Name);
            Console.WriteLine("Employee Designation : {0}", Designation);
            Console.WriteLine("Employee Basic : {0}", Basic);
            Console.WriteLine("Employee Allowance : {0}", Allowance);
            Console.WriteLine("Employee Deduction : {0}", Deduction);
            Console.WriteLine("Employee Netpay : {0}", NetPay);
            Console.WriteLine("Employee Grade : {0}", Grade);

        }
        public void CalNetpay()
        {
            NetPay = Basic + Allowance - Deduction;
        }

        public void ValidateGrade(int Lbasic)
        {
            if (Lbasic > 8000 && Lbasic <= 10000)
                Grade = 'A';
            else if (Lbasic > 5000 && Lbasic <= 8000)
                Grade = 'B';
            else if (Lbasic >= 3000 && Lbasic <= 5000)
                Grade = 'C';
            else if (Lbasic < 3000)
                Grade = 'D';

        }

        // static void Main(string[] args)
        public static void EmployeeMain()
        {
            Employee e = new Employee();
            e.Empno = 111;
            e.Name = "Kaviya";
            e.Basic = 9500;
            e.Allowance = 2000;
            e.Deduction = 200;
            e.Designation = "Associate";
            e.CalNetpay();
            e.ValidateGrade(e.Basic);
            e.ShowDetails();
            //Console.ReadLine();
            e = new Employee();
            e.Empno = 112;
            e.Name = "Kavi";
            e.Basic = 5000;
            e.Allowance = 1000;
            e.Deduction = 200;
            e.Designation = "Trainee";
            e.CalNetpay();
            e.ValidateGrade(e.Basic);
            e.ShowDetails();

        }
    }

}
