﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.IO;
using System.Runtime.Serialization.Formatters.Soap;

namespace Level1
{
    public class SerializationSamples
    {



        //To get vehicle details from user.
        public static Vehicle GetVehicleDetails(Vehicle vehicle)
        {
            Console.WriteLine("--Welcome to serialize/deserialize Vehicle's object using xml serialization--");
            Console.WriteLine("\n Please enter the vehicle details : ");
            Console.Write("\n Enter the vehicle name : ");
            vehicle.vehicleName = Console.ReadLine();
            Console.Write("\n Enter the vehicle type : ");
            vehicle.vehicleType = Console.ReadLine();

            return vehicle;
        }

        //To serialize Vehicle class object to xml file.
        public static void SerializeToXml<T>(T vehicle)
        {
            XmlSerializer xmlSerilizer = new XmlSerializer(typeof(T));
            TextWriter textWriter = new StreamWriter(@"D:\Learning\Learning\DotNetFrameWork\OutBound\Seriaize.xml");
            xmlSerilizer.Serialize(textWriter, vehicle);// Only public member are serialzed.
            textWriter.Close();
            Console.WriteLine("\n Vehicle class object has been serialized !");
        }

        //To serialize Vehicle class object to xml file.
        public static void SerializeToSoapFormatted<T>(T value)
        {
            SoapFormatter soapSerilizer = new SoapFormatter();
            FileStream textWriter = new FileStream(@"D:\Learning\Learning\DotNetFrameWork\OutBound\SoapSeriaize.xml",
                FileMode.Create, FileAccess.Write);
            soapSerilizer.Serialize(textWriter, value);// Only public member are serialzed.
            textWriter.Close();
            Console.WriteLine("\n Vehicle class object has been serialized !");
        }

        public static T DeSerializeFromSoap<T>(T value)
        {
            SoapFormatter soapSerializer = new SoapFormatter();

            FileStream fileStream = new FileStream(@"D:\Learning\Learning\DotNetFrameWork\OutBound\SoapSeriaize.xml",
                    FileMode.Open, FileAccess.Read);
            value = (T)soapSerializer.Deserialize(fileStream);
            return value;

        }

        public static T DeSerializeFromXML<T>(T value)
        {
            XmlSerializer soapSerializer = new XmlSerializer(typeof(T));

            FileStream fileStream = new FileStream(@"D:\Learning\Learning\DotNetFrameWork\OutBound\Seriaize.xml",
                    FileMode.Open, FileAccess.Read);
            value = (T)soapSerializer.Deserialize(fileStream);
            return value;

        }

        public static ShoppingMall GetShoppingMallDetails(ShoppingMall mall)
        {
            Console.WriteLine("--Welcome to serialize/deserialize Vehicle's object using xml serialization--");
            Console.WriteLine("\n Please enter the vehicle details : ");
            Console.Write("\n Enter the Mall name : ");
            mall.Name = Console.ReadLine();
            Console.Write("\n Enter the City : ");
            mall.City = Console.ReadLine();
            Console.Write("\n Enter the Square Feet : ");
            mall.SquareFeet = Convert.ToInt32(Console.ReadLine());
            return mall;

        }


        public static void GetDeserialize()
        {
            ShoppingMall shpml = DeSerializeFromSoap(new ShoppingMall());
            Console.WriteLine("Name : " + shpml.Name + ", city " + shpml.City);
            Vehicle vechile = DeSerializeFromXML(new Vehicle());
            Console.WriteLine("Name : " + vechile.vehicleName + ", Model " + vechile.vehicleType);
        }

    }

    [XmlRoot("Bike_Models")]
    public class Vehicle
    {
        public string vehicleName;
        [XmlElement("Vehicle_Category")]//To specify the tag name.
        public string vehicleType;
        private string vehicleModel = " UVBrand";
    }

    [Serializable]
    public class ShoppingMall
    {
        public string Name;
        public string City;
        public int SquareFeet;

    }

}
