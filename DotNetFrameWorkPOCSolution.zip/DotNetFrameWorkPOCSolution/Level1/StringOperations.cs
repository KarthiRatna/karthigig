﻿using System;
//using System.Threading.Tasks;

namespace StringOperations
{
    public class StringOperations
    {
        //String Replace
        public string ReplaceString(string Content, string searchString, string replaceString)
        {
            return Content.Replace(searchString, replaceString);
        }

        //String Length
        public int GetLengthOfString(string Content)
        {
            return Content.Length;
        }

        //String Length
        public string GetStringReverse(string Content)
        {
            char[] values;
            values = Content.ToCharArray();
            Array.Reverse(values);
            return new string(values);
        }

        //Extract String
        public string GetSubString(string Content)
        {
            return Content.Substring(5, 7);
        }

        //Extract String
        public string RemoveString(string Content, string stringToRemove)
        {
            return Content.Remove(11, 6);
        }

        // Insert String
        public string InsertString(string content, string stringToInsert)
        {
            return content.Insert(5, stringToInsert);
        }



    }
}
