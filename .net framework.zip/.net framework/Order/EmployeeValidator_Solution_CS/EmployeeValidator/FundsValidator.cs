﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml.Serialization;
using System.Xml;
using System.Xml.Linq;
using System.Text.RegularExpressions;
using EmployeeValidation;
//using  EmployeeValidation.FundsValidatorException;

namespace EmployeeValidation
{
    public class empValidator
    {
        public bool ProcessData(string sourceFolder, string fileName, string archiveFolder, string archiveFileName, SqlConnection connection)
        {
            List<Order> lstorder = new List<Order>();
            lstorder = ReadDataFromTxt(sourceFolder, fileName);
            List<Order> OrderData = SetValidationFlag(lstorder);
            InsertOrderData(OrderData, connection);
            DataTable process = ProductCommisionDatafromDb(connection);
            calculateCommisionData(OrderData, process, connection);
            archiveFileNamefromInput( sourceFolder,  fileName,  archiveFolder,  archiveFileName);
            return true;

        }
        public List<Order> ReadDataFromTxt(string sourceFolder, string fileName)
        {
            string InputFullPath = sourceFolder + fileName;
            List<Order> inputdata = new List<Order>();

            using (StreamReader sr = File.OpenText(InputFullPath))
            {
                string s = null;
                while ((s = sr.ReadLine()) != null)
                {
                    string[] st = s.Split(',');
                    Order order = new Order();
                    order.OrderId = st[0].ToString();
                    order.SalesPersonId = st[1].ToString();
                    order.OrderDate = st[2].Substring(0, 10).ToString();
                    order.ModelNbr = st[3].ToString();
                    order.Quantity = st[4].ToString();
                    order.CustomerId = st[5].ToString();
                    order.DeliveryDate = st[6].ToString();
                    inputdata.Add(order);

                }
            }
            return inputdata;
        }
        public List<Order> SetValidationFlag(List<Order> lstorder)
        {
            List<Order> items = new List<Order>();
            try
            {
                
                DateTime dt = new DateTime();
                DateTime dt1 = new DateTime();
                if (lstorder.Count > 0 && lstorder != null)
                {
                    foreach (Order eachorder in lstorder)
                    {
                        bool valid = true;
                        valid = valid && (!string.IsNullOrEmpty(eachorder.OrderId)) && (eachorder.OrderId.All(char.IsDigit));
                        valid = valid && (eachorder.SalesPersonId.StartsWith("SP")) && (eachorder.ModelNbr.Substring(2).Length == 3) && (eachorder.ModelNbr.Substring(2).All(char.IsDigit));
                        valid= valid && (DateTime.TryParseExact(eachorder.OrderDate, "MM/dd/yyyy", new CultureInfo("en-US"), DateTimeStyles.None, out dt));
                        valid = valid && (eachorder.ModelNbr.StartsWith("ML")) && (eachorder.ModelNbr.Substring(2).Length == 3) && (eachorder.ModelNbr.Substring(2).All(char.IsDigit));
                        valid = valid &&  (eachorder.Quantity.All(char.IsDigit));
                        valid = valid && (eachorder.CustomerId.StartsWith("CUS"));
                        valid = valid && (DateTime.TryParseExact(eachorder.DeliveryDate, "MM/dd/yyyy", new CultureInfo("en-US"), DateTimeStyles.None, out dt1));
                        if (valid)
                        {
                            valid = valid && ((dt1.Subtract(dt)).TotalDays >= 7);
                            if(valid)
                            {
                                eachorder.ValidFlag = "V";
                            }
                        }
                    
                        else
                        {
                            eachorder.ValidFlag = "E";
                        }
                        items.Add(eachorder);
                    }
                }
                
            }

            catch (Exception ex)
            {
                throw new EmployeeValidation.FundsValidatorException.OrderProcessorException(ex.Message);
            }
            return items;

        }
        public void InsertOrderData(List<Order> OrderData,SqlConnection connection)
        {
            string command = "Insert into SBA.Orders (OrderId , SalesPersonId ,  OrderDate,  ModelNbr ,  Quantity ,  CustomerId ,  DeliveryDate,ValidFlag) values (@OrderId , @SalesPersonId ,  @OrderDate,  @ModelNbr ,  @Quantity ,  @CustomerId ,  @DeliveryDate, @ValidFlag)";
            
            using (SqlCommand cmd = new SqlCommand(command, connection))
            {
                foreach (Order sm in OrderData)
                {
                    
                    cmd.Parameters.AddWithValue("@OrderId", sm.OrderId);
                    cmd.Parameters.AddWithValue("@SalesPersonId", sm.SalesPersonId);
                    cmd.Parameters.AddWithValue("@OrderDate", sm.OrderDate);
                    cmd.Parameters.AddWithValue("@ModelNbr", sm.ModelNbr);
                    cmd.Parameters.AddWithValue("@Quantity", sm.Quantity);
                    cmd.Parameters.AddWithValue("@CustomerId", sm.CustomerId);
                    cmd.Parameters.AddWithValue("@DeliveryDate", sm.DeliveryDate);
                    cmd.Parameters.AddWithValue("@ValidFlag", sm.ValidFlag);
                    connection.Open();
                    int i = cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                    connection.Close();

                }
            }
        }

        public DataTable ProductCommisionDatafromDb(SqlConnection connection)
        {
            DataTable dtProductCommisionData = new DataTable();
            string ProductCommisionData = "select * from SBA.Product_Commission";
            SqlDataAdapter da = new SqlDataAdapter(ProductCommisionData, connection);
               da.Fill(dtProductCommisionData);
                return dtProductCommisionData;
         }
        public void calculateCommisionData(List<Order> OrderData, DataTable process, SqlConnection connection)
        {
            List<string> ordercommission = new List<string>();
            SqlCommand cmd = new SqlCommand("Insert into SBA.Order_Commission (OrderId,Commission_amount) values (@OrderId,@Commission_amount)", connection);
            foreach (Order o in OrderData)
            {
                if (o.ValidFlag == "V")
                {
                    for (int i = 0; i < process.Rows.Count; i++)
                    {
                        string productmodelnbr = process.Rows[i]["ModelNbr"].ToString();
                        if (o.ModelNbr == productmodelnbr)
                        {
                            string productCommissionPercentage = process.Rows[i]["Commission_Percentage"].ToString();
                            string productBasePrice = process.Rows[i]["BasePrice"].ToString();
                            string value = ((float.Parse(productCommissionPercentage)) * (float.Parse(productBasePrice)) * (float.Parse(o.Quantity))).ToString();
                            connection.Open();
                            cmd.Parameters.AddWithValue("@OrderId", o.OrderId);
                            cmd.Parameters.AddWithValue("@Commission_amount", value);
                            int j = cmd.ExecuteNonQuery();
                            cmd.Parameters.Clear();
                            connection.Close();
                        }
                    }
                }
            }
        }
        public void archiveFileNamefromInput(string sourceFolder, string fileName, string archiveFolder, string archiveFileName)
        {
            string input = sourceFolder + fileName;
            string archive = archiveFolder + archiveFileName;
            
            File.Move(sourceFolder + fileName, archiveFolder + archiveFileName);
         }
   }
   
}
 


       
    