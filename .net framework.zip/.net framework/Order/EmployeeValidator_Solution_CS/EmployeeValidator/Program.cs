﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using EmployeeValidation;
//using FundsValidator;

namespace EmployeeValidation
{
    public class Program
    {
        public static void Main()
        {
            /*
             * Pass the file path, file names and connection string if any in this method alone. 
             * Do not hardcode in any other methods
             */

            SqlConnection connection = new SqlConnection(@"Data Source=NA03OSDVP00746\SQLEXPRESS;Initial Catalog=DBOrderValidation;Integrated Security=True");
            empValidator empValid = new empValidator();
            empValid.ProcessData(@"D:\Order\Input File\", "Order_0915.txt", @"D:\Order\Archive\", "Order_0915_Processed.txt", connection);
                       
        }
    }
}

