Use master
GO

IF  EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = 'DBOrderValidation')
DROP DATABASE DBOrderValidation
GO

CREATE DATABASE DBOrderValidation
GO

Use DBOrderValidation
GO
CREATE SCHEMA SBA
GO


CREATE TABLE SBA.Orders (
OrderId	Numeric(18,0) Not null Primary Key,
SalesPersonId	Varchar(50),
OrderDate	DateTime,
ModelNbr Varchar(50),
Quantity Varchar(50),
CustomerId Varchar(50),
DeliveryDate DateTime,
ValidFlag Varchar(50)
)

CREATE TABLE SBA.Product_Commission (
ModelNbr	Varchar(50) ,
Commission_Percentage	Varchar(50),
BasePrice Varchar(50)
)


CREATE TABLE SBA.Order_Commission (
OrderId	Numeric(18,0) Not null Primary Key,
Commission_amount	Varchar(50)
)
GO
