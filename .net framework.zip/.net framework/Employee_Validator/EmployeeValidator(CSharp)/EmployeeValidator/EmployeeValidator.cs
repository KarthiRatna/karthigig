﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Collections;
using System.Xml.Linq;
using System.Linq;
using System.Text.RegularExpressions;
using System.Data.Linq;
using System.Globalization;
using System.Xml.Serialization;
using System.IO;

namespace EmployeeValidation
{
    public class EmployeeValidator
    {
        /*
        * Do not remove the attached TestProject. It is meant for auto evaluation of your source code.
        * Do not attach any test classess to the attached test project.
        * Do not attach any new test projects.
        * You are not required to write any automated test cases. You are supposed to write only the code.
        */

        public void ProcessData(string xmlFilePath, string xmlFileName,string errorFilePath, string errorFileName, SqlConnection connection)
        {
            //Do your logic here
            //Step 1           
            //ReadAllEmployeesFromXmlFile
            List<Employee> lstemp = new List<Employee>();
            List<Employee> validemp = new List<Employee>();
            lstemp = ReadAllEmployeesFromXmlFile(xmlFilePath,xmlFileName);
            validemp = PickValidEmployees(lstemp);
            SaveValidEmployeesToDB(validemp, connection);
            ReadfromDBtoTxt(connection);

            //Step 2           
            //PickValidEmployees
            //Step 3
            //SaveValidEmployeesToDataBase           

        }
        public List<Employee> ReadAllEmployeesFromXmlFile(string xmlFilePath, string xmlFileName)
        {
            //Read the employee details from the xml file and return it in List collection
            //Do not hardcode the filename and the file path here
            //Do not return the date with time appended to it.
            
            string employeefile = xmlFilePath + xmlFileName;
            List<Employee> empdetail = new List<Employee>();
            XElement getelementfile = XElement.Load(employeefile);
            IEnumerable<XElement> items = getelementfile.Elements();
            foreach (var item in items)
            {
                string _EmployeeId = item.Element("EmployeeId").Value;
                string _EmployeeName = item.Element("EmployeeName").Value;
                string _EmailId = item.Element("EmailId").Value;
                string _DateOfJoining = item.Element("DateOfJoining").Value;
                empdetail.Add(new Employee(){ EmployeeId= _EmployeeId,
                                              EmployeeName= _EmployeeName,
                                              EmailId=_EmailId,
                                              DateOfJoining=_DateOfJoining
                                            });
            }
      return empdetail;
        }

        public List<Employee> PickValidEmployees(List<Employee> employees)
        {
            //Pick the valid employees from the List collection
            //Return the valid employees in a List
            List<Employee> valid = new List<Employee>();
            List<Employee> Invalid = new List<Employee>();
            List<string> empnum = new List<string>();
            bool isvalid = true;
            foreach(Employee em in employees)
            {
                Regex rgxisnumeric = new Regex(@"^\d$");
                Regex rgxisalphanumeric=new Regex( @"^\d*[a-zA-Z]{1,}\d*");
                Regex rgxemail = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
                Regex rgxDate= new Regex(@"^((0[1-9]|1[0-2])\/((0|1)[0-9]|2[0-9]|3[0-1])\/((19|20)\d\d))$");
                if (!empnum.Contains(em.EmployeeId))
                {
                    empnum.Add(em.EmployeeId);
                    isvalid = true;
                }
                else
                {
                    isvalid = false;
                }

                int empname;
               isvalid= isvalid && (!string.IsNullOrEmpty(em.EmployeeId)) && (rgxisnumeric.IsMatch(em.EmployeeId));
               isvalid= isvalid && (int.TryParse(em.EmployeeName, out empname)== false);
               isvalid= isvalid && (!string.IsNullOrEmpty(em.EmployeeName)) && (rgxisalphanumeric.IsMatch(em.EmployeeName));
               isvalid= isvalid && (!string.IsNullOrEmpty(em.EmailId)) && (rgxemail.IsMatch(em.EmailId));
               isvalid= isvalid && (!string.IsNullOrEmpty(em.DateOfJoining)) && (rgxDate.IsMatch(em.DateOfJoining));
                if(isvalid)
                {
                    DateTime dt;
                    isvalid= isvalid && DateTime.TryParseExact(em.DateOfJoining,"MM/dd/yyyy",new CultureInfo("en-US"),DateTimeStyles.None, out dt);
                }
                if(isvalid)
                {
                    valid.Add(em);
                }
                else
                {
                    Invalid.Add(em);
                }

            }
            SaveInValidEmployeesTotxt(Invalid);

            return valid;//Return only valid employees in List
        }

        public void SaveValidEmployeesToDB(List<Employee> employees, SqlConnection connection)
        {
            //Do not Prefix Database name in the SQL Query. Query should be "Insert into SBA.TableName"
            //Should not be "Insert into DatabaseName.SBA.TableName"
            //Do not hardcode the connection string here

            SqlConnection conn = connection;
            
            foreach(Employee emp in employees)
            {
                string command = "Insert into SBA.Employees (EmployeeId,EmployeeName,EmailId,DateOfJoining) values (@EmployeeId,@EmployeeName,@EmailId,@DateOfJoining)";
                SqlCommand cmd = new SqlCommand(command, conn);
            conn.Open();
            cmd.Parameters.AddWithValue("@EmployeeId",emp.EmployeeId);
            cmd.Parameters.AddWithValue("@EmployeeName",emp.EmployeeName);
            cmd.Parameters.AddWithValue("@EmailId",emp.EmailId);
            cmd.Parameters.AddWithValue("@DateOfJoining",DateTime.Parse(emp.DateOfJoining).ToString("MM/dd/yyyy"));
            cmd.ExecuteNonQuery();
            conn.Close();
            }
        }
        public void SaveInValidEmployeesTotxt(List<Employee> Invalid)
        {

            string invalidpath = @"D:\Employee_Validator\Error File\Emp_122014.xml";
            XmlSerializer serialise = new XmlSerializer(typeof(List<Employee>));
            TextWriter writeinvalid = new StreamWriter(invalidpath);
            serialise.Serialize(writeinvalid,Invalid);
            
       }
        public void ReadfromDBtoTxt(SqlConnection connection)
        {
            string newfilepath = @"D:\Employee_Validator\DBtoTXT\EmpoValid_" + DateTime.Now.ToString("MMyyyy") + ".txt";
            List<Employee> dbtotextlist = new List<Employee>();
            if (!File.Exists(newfilepath))
            {
                var g= File.Create(newfilepath);
                g.Close();
           }
            SqlCommand cmd = new SqlCommand("Select * from SBA.Employees",connection);
            connection.Open();
            SqlDataReader readdata = cmd.ExecuteReader();
            while (readdata.Read())
            {
                
                dbtotextlist.Add(new Employee
                {
                EmployeeId = readdata["EmployeeId"].ToString(),
                EmployeeName = readdata["EmployeeName"].ToString(),
                EmailId = readdata["EmailId"].ToString(),
                DateOfJoining = readdata["DateOfJoining"].ToString()
                });

            }
            connection.Close();
            StreamWriter sw = File.AppendText(newfilepath);
            foreach(Employee s in dbtotextlist)
            {   
                    sw.WriteLine(s.EmployeeId+","+s.EmployeeName+","+s.EmailId+","+ DateTime.Parse(s.DateOfJoining).ToString("MM/dd/yyyy"));
            }
            sw.Flush();
            sw.Close();
              }
    }
}
