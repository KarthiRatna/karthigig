﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;


namespace EmployeeValidation
{
    public class Employee
    {
        /*
        * Do not modify the return types of the below properties
        * 
        */
        //[XmlElement("EmployeeId")]
        public string EmployeeId { get; set; }
        //[XmlElement("EmployeeName")]
        public string EmployeeName { get; set; }
        //[XmlElement("EmailId")]
        public string EmailId { get; set; }
        //[XmlElement("DateOfJoining")]
        public string DateOfJoining { get; set; }
    }

    // Do not add new constructors
}
