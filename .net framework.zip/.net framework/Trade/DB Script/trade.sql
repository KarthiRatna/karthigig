Use master
GO

IF  EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = 'test')
DROP DATABASE test
GO

CREATE DATABASE test
GO

Use test
GO
CREATE SCHEMA SBA
GO

CREATE TABLE test(
Tradeid varchar(5) Not Null,
Name1  varchar(100),
Date    varchar(3),
Flag   numeric(18, 0),
Ordid   numeric(18, 0),
)

CREATE TABLE tbl (
Tradeid  varchar(5) Not Null,
Name1    varchar(3),
Ordid     numeric(18, 0),
)

GO
