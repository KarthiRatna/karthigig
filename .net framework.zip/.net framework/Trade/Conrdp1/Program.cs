﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml.Serialization;
using System.Xml;
using System.Xml.Linq;
using System.Configuration;


namespace Conrdp1
{
    class Program
    {
        static void Main(string[] args)
        {
            SqlConnection connectionObject = new SqlConnection(@"Data Source=NA03OSDVP00746\SQLEXPRESS;Initial Catalog= DBFXCalculation;Integrated Security=True");
            Method obj = new Method();
            obj.processdata(@"D:\Conrdp1\Input File\", "TradeOrders_032013.txt", @"D:\Conrdp1\ErrorLog\", "InvalidRecords_032014.txt", connectionObject, @"D:\Conrdp1\Archive\", "TradeOrders_032013_Processed.txt", @"D:\Conrdp1\XML\", "xml.xml");
            Console.WriteLine("Done");
            Console.ReadKey();
        }
    }
}