﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Conrdp1
{
    class Rate
    {
        private string rate;
        private string amt;
        private string nm;
        public string Rate1
        {
            get
            {
                return rate;
            }

            set
            {
                rate = value;
            }
        }

        public string Amt
        {
            get
            {
                return amt;
            }

            set
            {
                amt = value;
            }
        }

        public string Nm
        {
            get
            {
                return nm;
            }

            set
            {
                nm = value;
            }
        }
        public string Date { get; set; }
    }
}