﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml.Serialization;
using System.Xml;
using System.Xml.Linq;
using System.Text.RegularExpressions;

namespace Conrdp1
{
    class Method
    {
        public void processdata(string inputfilepath, string inputfilename, string errorpath, string errorfile, SqlConnection sqlconnectionobject, string archivepath, string archivefile, string xmlpath, string xmlfile)
        {
            List<Trade> trade = Readfile(inputfilepath, inputfilename);
            List<Trade> validtrade = pickfxvalidation(trade, errorpath, errorfile);
            savevalidentriesintoDB(validtrade, sqlconnectionobject);
            Insert(trade, sqlconnectionobject);
            saveFxrateintoDB(sqlconnectionobject);
            savearchivefile(archivepath, archivefile, inputfilepath, inputfilename);
            savetoxml(validtrade, xmlpath, xmlfile);
            Calculate(trade, sqlconnectionobject);
            DataSet ds = fillDataTable(sqlconnectionobject);
            compare(ds, sqlconnectionobject);
        }

        public List<Trade> Readfile(string inputfilepath, string inputfilename)
        {
            List<Trade> trades = new List<Trade>();
            try
            {
                string readline = string.Empty;
                readline = File.ReadAllText(inputfilepath + inputfilename);
                readline = readline.Replace("\r", "");
                string[] readlines = readline.Split('\n');
                List<string> innerlist = readlines.ToList();
                foreach (var item in innerlist)
                {
                    if (item.Contains(','))
                    {
                        string[] items = item.Split(',');
                        Trade tradeitem = new Trade();
                        tradeitem.Tradeid = items[0];
                        tradeitem.Name1 = items[1];
                        tradeitem.Date1 = items[2];
                        tradeitem.Date2 = items[3];
                        tradeitem.SchName = items[4];
                        tradeitem.Tradetype = items[5];
                        tradeitem.Cur = items[6];
                        tradeitem.Amt = items[7];
                        tradeitem.Ordid = items[8];
                        trades.Add(tradeitem);
                    }
                }
            }
            catch (Exception)
            {

            }
            return trades;
        }

        public List<Trade> pickfxvalidation(List<Trade> trades, string errorpath, string errorfile)
        {
            List<Trade> validtrade = new List<Trade>();
            List<Trade> invadiltrade = new List<Trade>();
            try
            {
                foreach (var trade in trades)
                {
                    string alp = trade.Tradeid.Substring(0, 2);
                    string alp1 = trade.Name1.Substring(3);
                    DateTime tradeDatevalue;
                    DateTime maturityvalue;
                    if (!string.IsNullOrWhiteSpace(trade.Tradeid) && trade.Tradeid.StartsWith("TR") &&
                        !string.IsNullOrWhiteSpace(trade.Name1) && trade.Name1.StartsWith("ERE") &&
                        alp1.All(char.IsDigit) && alp1.Length == 3 &&
                        DateTime.TryParseExact(trade.Date1, "MM/dd/yyyy", new CultureInfo("en-US"), DateTimeStyles.None, out tradeDatevalue)
                        && DateTime.TryParseExact(trade.Date2, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out maturityvalue)
                        && (Convert.ToDateTime(trade.Date2).Year - Convert.ToDateTime(trade.Date1).Year) > 5
                        && !string.IsNullOrWhiteSpace(trade.SchName) && !string.IsNullOrWhiteSpace(trade.Tradetype)
                        && trade.Cur.Length == 3 && !string.IsNullOrWhiteSpace(trade.Cur) && Regex.IsMatch(trade.Cur, "^[A-Z,a-z]+$")
                        && Convert.ToInt32(trade.Amt) > 0)
                    {
                        tradeDatevalue = Convert.ToDateTime(trade.Date1);
                        maturityvalue = Convert.ToDateTime(trade.Date2);
                        double totaldays = (maturityvalue - tradeDatevalue).TotalDays;
                        trade.Date1 = tradeDatevalue.ToShortDateString();
                        trade.Date1 = tradeDatevalue.ToString("MM/dd/yyyy");
                        trade.Flag = "V";
                        validtrade.Add(trade);
                    }
                    else
                    {
                        trade.Flag = "E";
                        invadiltrade.Add(trade);
                    }
                }
            }
            catch (Exception)
            {
            }
            savevalidtrade(invadiltrade, errorpath, errorfile);

            return validtrade;
        }

        public void savevalidtrade(List<Trade> invadiltrade, string errorpath, string errorfile)
        {
            if (invadiltrade != null && invadiltrade.Count > 0)
            {
                string path = errorpath + errorfile;
                try
                {
                    if (!File.Exists(path))
                    {

                        using (StreamWriter tw = File.CreateText(path))
                        {
                            tw.WriteLine("Tradeid|Name");
                            foreach (var trade in invadiltrade)
                            {
                                tw.WriteLine(trade.Tradeid + "," + trade.Name1);
                            }
                            tw.Close();
                        }
                    }
                    else if (File.Exists(path))
                    {
                        using (var tw = new StreamWriter(path, false))
                        {
                            tw.WriteLine("Tradeid|Name");
                            foreach (var trade in invadiltrade)
                            {
                                tw.WriteLine(trade.Tradeid + "," + trade.Name1);
                            }
                            tw.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                }
            }
        }

        public bool savevalidentriesintoDB(List<Trade> validtrade, SqlConnection sqlconnectionobject)
        {
            if (validtrade != null && validtrade.Count > 0)
            {
                try
                {
                    foreach (var trd in validtrade)
                    {
                        using (SqlCommand command = sqlconnectionobject.CreateCommand())
                        {
                            command.CommandText = @"Insert into test(Tradeid,Name1,Date,Flag,Ordid)values(@Tradeid,@Name1,@Date,@Flag,@Ordid)";
                            command.Parameters.AddWithValue("@Tradeid", trd.Tradeid);
                            command.Parameters.AddWithValue("@Name1", trd.Name1);
                            command.Parameters.AddWithValue("@Date", trd.Date1);
                            command.Parameters.AddWithValue("@Flag", trd.Flag);
                            command.Parameters.AddWithValue("@Ordid", trd.Ordid);
                            sqlconnectionobject.Open();
                            command.ExecuteNonQuery();
                            sqlconnectionobject.Close();
                        }
                    }
                }
                catch (Exception)
                {

                }
            }
            return true;
        }

        public void Insert(List<Trade> validTrade, SqlConnection con)
        {
            List<Trade> obj = new List<Trade>();
            try
            {
                string querystring = "select * from test";
                SqlCommand command = new SqlCommand(querystring, con);
                con.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Trade tr = new Trade
                        {
                            Tradeid = reader["Tradeid"].ToString(),
                            Name1 = reader["Name1"].ToString(),
                        };
                        obj.Add(tr);
                    }
                    con.Close();
                }

                List<string> ids = obj.Select(a => a.Tradeid).ToList();
                List<Trade> distinct = validTrade.Where(a => !ids.Contains(a.Tradeid)).ToList();

                if (validTrade != null && validTrade.Count > 0)
                {
                    foreach (var item in distinct)
                    {
                        using (SqlCommand com = con.CreateCommand())
                        {
                            com.CommandText = @"Insert into tbl(Tradeid,Name1,Ordid)values(@Tradeid,@Name1,@Ordid)";
                            com.Parameters.AddWithValue("@Tradeid", item.Tradeid);
                            com.Parameters.AddWithValue("@Name1", item.Name1);
                            com.Parameters.AddWithValue("@Ordid", item.Ordid);
                            con.Open();
                            com.ExecuteNonQuery();
                            con.Close();
                        }
                    }
                }
            }
            catch (Exception)
            { }
        }

        public bool saveFxrateintoDB(SqlConnection sqlconnectionobject)
        {
            List<Trade> trades = new List<Trade>();
            List<Rate> rt = new List<Rate>();
            try
            {
                string querystring = "select * from test";
                SqlCommand command = new SqlCommand(querystring, sqlconnectionobject);
                sqlconnectionobject.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Trade obj = new Trade
                        {
                            Tradeid = reader["Tradeid"].ToString(),
                            Name1 = reader["Name1"].ToString(),
                            Date1 = reader["Date"].ToString(),
                        };
                        trades.Add(obj);
                    }
                    sqlconnectionobject.Close();
                }
            }
            catch (Exception ex)
            {
            }
            if (trades != null && trades.Count > 0)
            {
                DateTime calDate = new DateTime();
                foreach (var trd in trades)
                {
                    Rate obj = new Rate();
                    obj.Rate1 = trd.Tradeid;
                    obj.Nm = trd.Name1;
                    if (obj.Nm == "ERR")
                    {
                        obj.Amt = trd.Tradeid;
                    }
                    else if (obj.Nm == "ERE101")
                    {
                        for (double i = 1; i <= 6; i++)
                        {
                            calDate = Convert.ToDateTime(trd.Date1).AddDays(i);
                            if (IsHoliday(calDate, sqlconnectionobject))
                            {
                                obj.Date = calDate.ToString();
                                break;
                            }
                        }
                    }
                    rt.Add(obj);
                }
            }
            return true;
        }

        public bool IsHoliday(DateTime dt, SqlConnection sqlconnectionobject)
        {
            List<DateTime> holidays = new List<DateTime>();
            try
            {
                string str = "Select * from holi";
                SqlCommand cmd = new SqlCommand(str, sqlconnectionobject);
                sqlconnectionobject.Open();
                using (SqlDataReader rd = cmd.ExecuteReader())
                {
                    while (rd.Read())
                    {
                        DateTime fetch = Convert.ToDateTime(rd["holiday"]);
                        holidays.Add(fetch);
                    }
                    sqlconnectionobject.Close();
                }
            }
            catch (Exception)
            {
                throw;
            }
            bool ischeck = false;
            //ischeck = (holidays.Any(x => x.Date == dt) || dt.DayOfWeek == DayOfWeek.Saturday || dt.DayOfWeek == DayOfWeek.Sunday);
            foreach (var item in holidays)
            {
                if ((item.Date == dt) || dt.DayOfWeek == DayOfWeek.Saturday || dt.DayOfWeek == DayOfWeek.Sunday)
                {
                    ischeck = true;
                    break;
                }
            }
            if (ischeck)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public void savearchivefile(string archivepath, string archivefile, string inputfilepath, string inputfilename)
        {
            string target = archivepath + archivefile;
            string source = inputfilepath + inputfilename;
            try
            {
                if (!Directory.Exists(archivepath))
                {
                    Directory.CreateDirectory(archivepath);
                }
                System.IO.File.Copy(source, target, true);
            }
            catch (Exception)
            {

            }
        }

        public void savetoxml(List<Trade> validtrade, string xmlpath, string xmlfile)
        {
            string path = xmlpath + xmlfile;
            try
            {
                using (StringWriter strm = new StringWriter(new StringBuilder()))
                {
                    XmlSerializer xml = new XmlSerializer(typeof(List<Trade>));
                    xml.Serialize(strm, validtrade);
                    var x = strm.ToString();
                    if (!File.Exists(path))
                    {
                        using (StreamWriter tr = File.CreateText(path))
                        {
                            tr.WriteLine(x);
                            tr.Close();
                        }
                    }
                    else if (File.Exists(path))
                    {
                        using (var tw = new StreamWriter(path, false))
                        {
                            tw.WriteLine(x);
                            tw.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
            xmlwrite(xmlpath, xmlfile);
        }

        public void xmlwrite(string xmlpath, string xmlfile)
        {
            List<Trade> studentLst = new List<Trade>();

            string path = xmlpath + xmlfile;
            var xmlDoc = XDocument.Parse(
                 File.ReadAllText(path, System.Text.Encoding.UTF8));
            // List<Trade> studentLst = xmlDoc.Descendants("Trade").Select(d =>
            //new Trade
            //{
            //    Tradeid = d.Element("Tradeid").Value,
            //    Name1 = d.Element("Name1").Value,
            //}).ToList();

            foreach (var item in xmlDoc.Descendants("Trade"))
            {
                Trade obj = new Trade();
                obj.Tradeid = item.Element("Tradeid").Value;
                obj.Name1 = item.Element("Name1").Value;
                studentLst.Add(obj);
            }


            string str = @"D:\Conrdp1\XML\xml1.txt";
            if (File.Exists(str))
            {
                using (var tw = new StreamWriter(str, false))
                {
                    foreach (var item in studentLst)
                    {
                        tw.WriteLine(item.Tradeid + "," + item.Name1);
                    }
                    tw.Close();
                }
            }
        }

        public List<Trade> Calculate(List<Trade> trade, SqlConnection con)
        {
            List<Trade> calcul = new List<Trade>();
            if (trade != null)
            {
                foreach (var item in trade)
                {
                    Trade obj = new Trade();
                    obj.Tradeid = item.Tradeid;
                    obj.Name1 = item.Name1;
                    if (obj.Name1 == "ERE101")
                    {
                        string rate = "100";
                        obj.Amt = (Convert.ToInt64(item.Amt) * Convert.ToInt64(rate)).ToString();
                    }
                    else if (obj.Name1 == "ERE10")
                    {
                        obj.Amt = (100 * 100).ToString();
                    }
                    calcul.Add(obj);
                }
            }
            int num = 655;
            int str = 200 * 10 + 300 * 11 + (num - 500) * 12;

            return calcul;
        }

        public DataSet fillDataTable(SqlConnection sqlconnectionobject)
        {
            string query = "select Tradeid,Name1,Ordid from test";
            SqlCommand cmd = new SqlCommand(query, sqlconnectionobject);
                         sqlconnectionobject.Open();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                //DataTable dt = new DataTable();
                DataSet ds = new DataSet();
                //da.Fill(dt);
                da.Fill(ds);
                sqlconnectionobject.Close();
                //return dt;
                return ds;
            
        }

        public bool compare(DataSet ds, SqlConnection sqlconnectionobject)
        {
            List<Trade> read = new List<Trade>();
            SqlCommand cmd = new SqlCommand("select Tradeid,Name1,Ordid from tbl", sqlconnectionobject);
            sqlconnectionobject.Open();
            using (SqlDataReader rd = cmd.ExecuteReader())
            {
                while (rd.Read())
                {
                    Trade obj = new Trade();
                    obj.Tradeid = rd["Tradeid"].ToString();
                    obj.Name1 = rd["Name1"].ToString();
                    obj.Ordid = rd["Ordid"].ToString();
                    read.Add(obj);
                }
            }
            sqlconnectionobject.Close();

            foreach (var item in read)
            {
                if (item.Tradeid != null)
                {
                    foreach (DataTable dt in ds.Tables)
                    {
                        foreach (DataRow d in dt.Rows)
                        {
                            if (item.Ordid == (d["Ordid"].ToString()))
                            {
                                Trade obj = new Trade();
                                obj.Amt = Convert.ToInt32(100 * 100).ToString();
                                obj.Ordid = item.Ordid;
                                SqlCommand cmdd = new SqlCommand("Insert into cal(Amt,Ordid)values('" + obj.Amt + "','" + obj.Ordid + "')", sqlconnectionobject);
                                sqlconnectionobject.Open();
                                cmdd.ExecuteNonQuery();
                                sqlconnectionobject.Close();
                                break;
                            }
                        }
                    }
                }
            }
            return true;
        }
    }
}