﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Conrdp1
{
    public class Trade
    {
        private string tradeid;
        public string Tradeid
        {
            get
            {
                return tradeid;
            }

            set
            {
                tradeid = value;
            }
        }

        public string Name1
        {
            get
            {
                return Name;
            }

            set
            {
                Name = value;
            }
        }

        private string Name;
        public string Date1 { get; set; }
        public string Date2 { get; set; }
        public string SchName { get; set; }
        public string Tradetype { get; set; }
        public string Cur { get; set; }
        public string Amt { get; set; }
        public string Flag { get; set; }
        public string Ordid { get; set; }
    }
}