﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;
using System.Data.SqlClient;

namespace Tarriffs
{
    public class Tariff
    {
        public string UserId { get; set; }
        public string UserName { get; set; }
        public string Category { get; set; }
        public string LastMeterReading { get; set; }
        public string CurrentMeterReading { get; set; }
        public string ReadingDate { get; set; }
        public string NoofUnits { get; set; }
        public string CalculatedAmount { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            string inputfile = @"D:\Tarriffs\Input file\Tarriff_0919.txt";
            List<Tariff> read = new List<Tariff>();
            StreamReader sr = File.OpenText(inputfile);
            string s= null;
            while((s= sr.ReadLine())!=null)
            {
                string[] item = s.Split(',');
                Tariff tar = new Tariff();
                tar.UserId= item[0];
                tar.UserName= item[1];
                tar.Category= item[2];
                tar.LastMeterReading= item[3];
                tar.CurrentMeterReading= item[4];
                tar.ReadingDate= item[5];
                bool valid = validandlogger(tar.UserId, tar.UserName, tar.Category, tar.LastMeterReading, tar.CurrentMeterReading, tar.ReadingDate);
                if (valid)
                {
                    double[] tarriffcalculation = tarriffcalc(tar.LastMeterReading, tar.CurrentMeterReading);
                    Tariff final = new Tariff();
                    final.UserId = item[0];
                    final.UserName = item[1];
                    final.NoofUnits = tarriffcalculation[0].ToString();
                    final.CalculatedAmount = tarriffcalculation[1].ToString();
                    SqlConnection conn= new SqlConnection(@"Data Source=NA03OSDVP00746\SQLEXPRESS;Initial Catalog=DBTarriffValidation;Integrated Security=True");
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("Insert into dbo.custom values ('" + final.UserId + "','" + final.UserName + "','" + final.NoofUnits + "','" + final.CalculatedAmount + "')", conn);

                    int i = cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
        }
        public static bool validandlogger(string UserId, string UserName, string Category, string LastMeterReading, string CurrentMeterReading, string ReadingDate)
        {
            bool valid = true;
            DateTime dt;
            Regex name = new Regex("^[a-zA-Z0-9]{6}$");
            valid = valid && (!string.IsNullOrEmpty(UserId)) && UserId.All(char.IsDigit);
            valid = valid && (!string.IsNullOrEmpty(UserName)) && name.IsMatch(UserName);
            string[] vcategory = { "COM", "DOM", "OTD" };
            valid = valid && vcategory.Contains(Category);
            valid = valid && LastMeterReading.All(char.IsDigit);
            valid = valid && CurrentMeterReading.All(char.IsDigit);
            valid = valid && DateTime.TryParseExact(ReadingDate, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out dt);
            if (!valid)
            {

                string errortextfile = @"D:\Tarriffs\Error_log\";
                string errorfile = "Error_"+DateTime.Now.ToString("MMyyyy")+".txt";
                if (!File.Exists(errortextfile + errorfile))
                {
                    var i = File.Create(errortextfile + errorfile);
                    i.Close();
                }
                StreamWriter sw = File.AppendText(errortextfile + errorfile);
                sw.WriteLine(UserId + "," + UserName + "," + Category + "," + LastMeterReading + "," + CurrentMeterReading + "," + ReadingDate);
                sw.Flush();
                sw.Close();
            }
            else
            {
                return true;
            }
            return false;

        }
        public static double[] tarriffcalc(string LastMeterReading, string CurrentMeterReading)
        {
            int LMeterReading = 0;
            int CMeterReading = 0;
            LMeterReading = int.Parse(LastMeterReading);
            CMeterReading = int.Parse(CurrentMeterReading);
            int units = CMeterReading - LMeterReading;
            double totalamount = 0;
            if (units <= 100)
            {
                var baserate = 20;
                totalamount = (units * 1) + baserate;
            }
            else if (units <= 200)
            {
                var baserate = 20;
                totalamount = (units * 1.5) + baserate;
            }
            else if (units <= 500)
            {
                var baserate = 40;
                totalamount = 250 +((units-200)*3)+baserate;
            }
            else if (units > 500)
            {
                var baserate = 40;
                totalamount = 1700 + ((units - 500) * 5.75) + baserate;
            }
            return new double[] {units,totalamount};
        }
    }
}
