Use master
GO

IF  EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = 'DBTarriffValidation')
DROP DATABASE DBTarriffValidation
GO

CREATE DATABASE DBTarriffValidation
GO

Use DBTarriffValidation
GO
CREATE SCHEMA SBA
GO

CREATE TABLE dbo.custom
(
UserId	Varchar(50) Not null ,
UserName	Varchar(50),
NoofUnits Varchar(50),
CalculatedAmount Varchar(50)
)


