﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;

namespace EmployeeValidation
{
    public class Program
    {
        public static void Main()
        {
              /*
               * Pass the file path, file names and connection string if any in this method alone. 
               * Do not hardcode in any other methods
               */
            SqlConnection connection = new SqlConnection(@"Data Source=NA03OSDVP00746\SQLEXPRESS;Initial Catalog=DBFundsValidation;Integrated Security=True");
            FundsValidator empValidator = new FundsValidator();
            empValidator.ProcessData(@"D:\Funds\Input file\", "Funds_0919.txt", connection, "error_0919.txt", @"D:\Funds\Error_log\");
                       
        }
    }
}

