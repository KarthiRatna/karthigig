﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;
using System.Xml.Serialization;
using System.Text.RegularExpressions;
using System.Xml;

namespace EmployeeValidation
{
    public class FundsValidator
    {
        /*
        * Do not remove the attached TestProject. It is meant for auto evaluation of your source code.
        * Do not attach any test classess to the attached test project.
        * Do not attach any new test projects.
        * You are not required to write any automated test cases. You are supposed to write only the code.
        */

        public void ProcessData(string FilePath, string FileName, SqlConnection connection, string errorFilename, string errorFilepath)
        {
            List<Funds> Alllstfunds = new List<Funds>();
            List<Funds> Validlstfunds = new List<Funds>();
            Alllstfunds= ReadValuesfromInputfile(FilePath, FileName);
            Validlstfunds = GetValidFunds(Alllstfunds,  errorFilename,  errorFilepath);
            SaveValidListToDB(Validlstfunds,connection);
            List<Funds> Removeddup= GerPerFundDetails(Validlstfunds);
            CalculateNavandSaveToDatabase(Removeddup,connection);



        }
        public List<Funds> ReadValuesfromInputfile(string FilePath, string FileName)
        {
            List<Funds> AllListfunds = new List<Funds>();
            string s1= null;
            StreamReader sw = File.OpenText(FilePath + FileName);
            while ((s1 = sw.ReadLine()) != null)
            {
                Funds fund = new Funds();
                string[] s = s1.Split(',');
                fund.FundsID = s[0].ToString();
                fund.SubfundID = s[1].ToString();
                fund.Asset = s[2].ToString();
                fund.La = s[3].ToString();
                fund.o = s[4].ToString();
                AllListfunds.Add(fund);
        
            }
            return AllListfunds;
        }

         public List<Funds> GetValidFunds(List<Funds> Alllstfunds, string errorFilename,string  errorFilepath)
         {
             try
             {
                 List<Funds> validlist = new List<Funds>();
                 List<Funds> Invalid = new List<Funds>();
                 foreach (Funds x in Alllstfunds)
                 {
                     bool valid = true;
                     valid = valid && (!string.IsNullOrEmpty(x.FundsID) && x.FundsID.StartsWith("F")) && x.FundsID.Length == 4 && x.FundsID.Substring(1).Length == 3 && x.FundsID.Substring(1).All(char.IsDigit);
                     valid = valid && (!string.IsNullOrEmpty(x.SubfundID)) && x.SubfundID.StartsWith("SF") && x.SubfundID.Length == 5 && x.SubfundID.Substring(2).Length == 3 && x.SubfundID.Substring(2).All(char.IsDigit);
                     valid = valid && (!string.IsNullOrEmpty(x.Asset)) && x.Asset.All(char.IsDigit);
                     valid = valid && (!string.IsNullOrEmpty(x.La)) && x.La.All(char.IsDigit);
                     valid = valid && (!string.IsNullOrEmpty(x.o)) && x.o.All(char.IsDigit);
                     if (valid)
                     {
                         validlist.Add(x);
                     }
                     else
                     {
                         Invalid.Add(x);
                     }
                 }
                 SaveInValidinErrorTxt(Invalid, errorFilename, errorFilepath);
                 return validlist;
             }
             catch (Exception ex)
             {
                 throw new FundsValidatorException(ex.Message);
             }
         }
        public void SaveInValidinErrorTxt(List<Funds> Invalid,string errorFilename,string errorFilepath)
        {
            if (Invalid.Count > 0 && Invalid != null)
            {
                if (!File.Exists(errorFilepath + errorFilename))
                {
                    var i=File.Create(errorFilepath + errorFilename);
                    i.Close();
                }
                 StreamWriter sw = File.AppendText(errorFilepath+errorFilename);
                foreach (Funds f in Invalid)
                {
                    sw.WriteLine(f.FundsID+","+f.SubfundID+","+f.Asset+","+f.La+","+f.o);
                }
                sw.Flush();
                sw.Close();
                
            }
        }
        public void SaveValidListToDB(List<Funds> Validlstfunds, SqlConnection connection)
        {
            try
            {
                foreach (Funds f in Validlstfunds)
                {
                    connection.Open();
                    SqlCommand cmd = new SqlCommand(("Insert into SBA.Fund_Details (FundId,SubFundId,Assets,Liabilities,OutstandingShares) Values ( '" + f.FundsID + "','" + f.SubfundID + "','" + f.Asset + "','" + f.La + "','" + f.o + "')"), connection);
                    int i = cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                throw new FundsValidatorException(ex.Message);
            }
            
        }
        public List<Funds> GerPerFundDetails(List<Funds> Validlists)
        {
            List<string> s = new List<string>();
            List<Funds> RemoveDup = new List<Funds>();
            String[] r = (from a in Validlists
                     select a.FundsID).Distinct().ToArray();
            foreach (String x in r)
            {
                int assetnum = 0;
                int lanum = 0;
                int onum=0;
                foreach (Funds q in Validlists)
                {
                    if (x.ToString() == q.FundsID)
                    {
                        assetnum = assetnum + int.Parse(q.Asset);
                        lanum=lanum+int.Parse(q.La);
                        onum=onum+int.Parse(q.o);
                    }
                }
                Funds f= new Funds();
                f.FundsID=x.ToString();
                f.Asset=assetnum.ToString();
                f.La=lanum.ToString();
                f.o= onum.ToString();
                RemoveDup.Add(f);
          
            }
            return RemoveDup;
        }
        public void CalculateNavandSaveToDatabase(List<Funds> Removeddup,SqlConnection connection)
        {
            List<Funds> NAVClaculated = new List<Funds>();
            foreach(Funds item in Removeddup)
            {
                 item.NAV= (float)(Math.Round(((float.Parse(item.Asset) - float.Parse(item.La))/(float.Parse(item.o))),2));
                
                NAVClaculated.Add(item);
            }
            foreach (Funds f in NAVClaculated)
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand(("Insert into SBA.Nav_Report (FundId,Assets,Liabilities,OutstandingShares,Nav) Values ( '" + f.FundsID + "','" + f.Asset + "','" + f.La + "','" + f.o +"','"+f.NAV+ "')"), connection);
                int i = cmd.ExecuteNonQuery();
                cmd.Parameters.Clear();
                connection.Close();
            }
        }
    }
}

       