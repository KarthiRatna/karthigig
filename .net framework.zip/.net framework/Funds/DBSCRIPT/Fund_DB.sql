Use master
GO

IF  EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = 'DBFundsValidation')
DROP DATABASE DBFundsValidation
GO

CREATE DATABASE DBFundsValidation
GO

Use DBFundsValidation
GO
CREATE SCHEMA SBA
GO


CREATE TABLE SBA.Fund_Details (
FundId	Varchar(50) Not null ,
SubFundId	Varchar(50),
Assets	Varchar(50),
Liabilities Varchar(50),
OutstandingShares Varchar(50)
)

CREATE TABLE SBA.Nav_Report (
FundId	Varchar(50) Not null Primary Key,
Assets	Varchar(50),
Liabilities Varchar(50),
OutstandingShares Varchar(50),
Nav Varchar(50)
)

GO

delete SBA.Fund_Details
select * from SBA.Fund_Details;
select * from SBA.Nav_Report;