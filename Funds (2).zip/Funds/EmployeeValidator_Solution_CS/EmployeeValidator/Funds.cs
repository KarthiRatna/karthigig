﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeValidation
{
    public class Funds
    {
        /*
        * Do not modify the return types of the below properties
        * 
        */

        public string FundsID { get; set; }
        public string SubfundID { get; set; }
        public string Asset { get; set; }
        public string La { get; set; }
        public string o { get; set; }
        public float NSV { get; set; }
    }

    // Do not add new constructors
}
