﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;

namespace EmployeeValidation
{
    public class Program
    {
        public static void Main()
        {
              /*
               * Pass the file path, file names and connection string if any in this method alone. 
               * Do not hardcode in any other methods
               */
            SqlConnection connection = new SqlConnection(@"Data Source=PC334381;Initial Catalog=DBFundsValidation;Integrated Security=True");
            FundsValidator empValidator = new FundsValidator();
            empValidator.ProcessData(@"C:\Users\302594\Desktop\.net framework\Funds\Input file\", "Funds_input.txt", connection, "error_log.txt", @"C:\Users\302594\Desktop\.net framework\Funds\Error_log\");
                       
        }
    }
}

