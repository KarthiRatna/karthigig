﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmployeeValidation
{
   
    public class FundsValidatorException : Exception
    {
        public FundsValidatorException()
            : base()
        {

        }

        public FundsValidatorException(string message)
            : base(message)
        {

        }
    }
}
