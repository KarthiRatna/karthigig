﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;
using System.Xml.Serialization;
using System.Text.RegularExpressions;
using System.Xml;

namespace EmployeeValidation
{
    public class FundsValidator
    {
        /*
        * Do not remove the attached TestProject. It is meant for auto evaluation of your source code.
        * Do not attach any test classess to the attached test project.
        * Do not attach any new test projects.
        * You are not required to write any automated test cases. You are supposed to write only the code.
        */

        public void ProcessData(string FilePath, string FileName, SqlConnection connection, string errorFilename, string errorFilepath)
        {

            FundsValidator funds = new FundsValidator();
            List<Funds> lstemp = new List<Funds>();
           
            lstemp = funds.ReadAllEmployeesFromtextFile(FilePath, FileName);
            //Calculate NAV
            lstemp = CalculateNAV(lstemp);
            //Remove duplicates
            lstemp = RemoveDup(lstemp,errorFilename, errorFilepath);
            lstemp=Validation(lstemp);
            SavetoDB(lstemp,connection);
        }

        private void SavetoDB(List<Funds> lstemp, SqlConnection connection)
        {
            string query = @"Insert into funds(FundsID,SFundsID,Asset,la,o,nav) values(@FundsID,@SFundsID,@Asset,@la,@o,@nav)";
            connection.Open();
            using (SqlCommand sqlcommand = new SqlCommand(query, connection))
            {
                foreach (var a in lstemp)
                {
                    sqlcommand.Parameters.AddWithValue("@FundsID", a.FundsID);
                    sqlcommand.Parameters.AddWithValue("@SFundsID", a.SubfundID);
                    sqlcommand.Parameters.AddWithValue("@Asset", a.Asset);
                    sqlcommand.Parameters.AddWithValue("@la", a.La);
                    sqlcommand.Parameters.AddWithValue("@o", a.o);
                    sqlcommand.Parameters.AddWithValue("@nav", a.NSV);
                    int i = sqlcommand.ExecuteNonQuery();
                    sqlcommand.Parameters.Clear();
                }
            }
        }

        private List<Funds> Validation(List<Funds> lstemp)
        {
            Regex isNumeric = new Regex(@"^\D+$");
            Regex isAlpha = new Regex(@"^\W+$");
            lstemp = (from x in lstemp where !string.IsNullOrEmpty(x.FundsID) && !isNumeric.IsMatch(x.Asset.ToString()) select x).ToList();
            return lstemp;
        }

        private List<Funds> RemoveDup(List<Funds> lstemp, string errorFilename, string errorFilepath)
        {
            List<Funds> lstempUnique = new List<Funds>();
            List<Funds> lstempDup = new List<Funds>();
            lstempDup=lstemp.GroupBy(x=>new{x.FundsID,x.SubfundID}).Where(d=>d.Count()>1).Select(x=>x.First()).ToList();
            lstempUnique = lstemp.GroupBy(x => new { x.FundsID, x.SubfundID }).Select(a => a.First()).Distinct().ToList();

            TextWriter tw = new StreamWriter(errorFilepath + errorFilename);
            for (int i = 0; i < lstempDup.Count; i++)
            {
                tw.Write(lstempDup[i].FundsID + ',' + lstempDup[i].SubfundID + ',' + lstemp[i].Asset + ',' + lstemp[i].La + ',' + lstemp[i].o+Environment.NewLine);
             }
            tw.Close();
            return lstempUnique;
        }

        public List<Funds> CalculateNAV(List<Funds> lstemp)
        {
            float nav;
            List<Funds> lstempOrdered = new List<Funds>();
            lstempOrdered = lstemp.OrderBy(a => a.FundsID).ToList();
            foreach (var a in lstempOrdered)
            {
                nav = Convert.ToInt16(a.Asset) * Convert.ToInt16(a.La);
                a.NSV = nav / Convert.ToInt16(a.o);
            }
            return lstemp;
        }
        public List<Funds> ReadAllEmployeesFromtextFile(string FilePath, string FileName)
        {
            List<Funds> fList = new List<Funds>();
            
            StreamReader file = new StreamReader(FilePath + FileName);
            string line;
            while ((line = file.ReadLine()) != null)
            {
                string[] item = line.Trim().Split(',');
                fList.Add(new Funds()
                {
                    FundsID = item[0],
                    SubfundID=item[1],
                    Asset=item[2],
                    La = item[3],
                    o=item[4]
                });
            }

            return fList;
        }
    }
}