﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using EmployeeValidation;
using FundsValidator;

namespace EmployeeValidation
{
    public class Program
    {
        public static void Main()
        {
            /*
             * Pass the file path, file names and connection string if any in this method alone. 
             * Do not hardcode in any other methods
             */

            SqlConnection connection = new SqlConnection(@"Data Source=PC291599\MSSVR2014ENTER;Initial Catalog=DBOrderProcessing;Integrated Security=True");
            empValidator empValid = new empValidator();
            empValid.ProcessData(@"D:\Framework\", "input.txt",@"C:\Archive\","Test_1123.txt",connection);
                       
        }
    }
}

