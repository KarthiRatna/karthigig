﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeValidation
{
    public class Order
    {
        public string OrderId { get; set; }
        public string SalesPersonId { get; set; }
        public string OrderDate { get; set; }
        public string ModelNbr { get; set; }
        public string Quantity { get; set; }
        public string CustomerId { get; set; }
        public string DeliveryDate { get; set; }
        public string ValidFlag { get; set; }

    }

    // Do not add new constructors
}
