﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml.Serialization;
using System.Xml;
using System.Xml.Linq;
using System.Text.RegularExpressions;
using EmployeeValidation;
using static EmployeeValidation.FundsValidatorException;

namespace FundsValidator
{
    public class empValidator
    {
        public bool ProcessData(string sourceFolder, string fileName, string archiveFolder, string archiveFileName, SqlConnection connection)
        {

            List<Order> Orders = ReadAllDataFromInputFile(sourceFolder,fileName);

            

            //Step 2
            //SetValidationFlag
            List<Order> ValidOrder = SetValidationFlag(Orders);

            //Step 3
            //InsertOrderData
            bool insertBit = InsertOrderData(ValidOrder, connection);

            //Step 4            
            //GetProductsCommission


            DataTable dtprodcomm = GetProductsCommission(connection);

            //Step 5

            return true;
        }


        public List<Order> ReadAllDataFromInputFile(string sourceFolder, string fileName)
        {
            List<Order> inputlist = null;

            {
                try
                {
                    inputlist = new List<Order>();
                    var inputlines = File.ReadAllLines(sourceFolder + fileName);
                    foreach (var item in inputlines)
                    {
                        string[] datas = item.Split(',');
                        Order orderdetails = new Order()
                        {
                            OrderId = datas[0],
                            SalesPersonId = datas[1],
                            OrderDate = Convert.ToDateTime(datas[2]).ToShortDateString(),
                            ModelNbr = datas[3],
                            Quantity = datas[4],
                            CustomerId = datas[5],
                            DeliveryDate = datas[6]
                        };
                        inputlist.Add(orderdetails);
                    }
                
                }
                catch(OrderProcessorException)
                {
                    throw new OrderProcessorException();
                }
            }


            return inputlist;
        }



        public List<Order> SetValidationFlag(List<Order> Orders)
        {
            List<Order> validList = null;

            validList = new List<Order>();

            int num = 0;

            DateTime dtOrderdate;
            DateTime dtdeliverydate;

            if (Orders != null && Orders.Count >0)
            {
                foreach(var item in Orders)
                {
                    if(int.TryParse(item.OrderId, out num) &&
                        item.SalesPersonId.StartsWith("SP") && item.SalesPersonId.Substring(2).Length == 3 && int.TryParse(item.SalesPersonId.Substring(2), out num) &&
                        DateTime.TryParse(item.OrderDate, out dtOrderdate) &&
                         item.ModelNbr.StartsWith("ML") && item.ModelNbr.Substring(2).Length == 3 && int.TryParse(item.ModelNbr.Substring(2), out num) &&
                        int.TryParse(item.Quantity, out num) && DateTime.TryParse(item.DeliveryDate, out dtdeliverydate) && (Convert.ToDateTime(item.DeliveryDate) - Convert.ToDateTime(item.OrderDate)).TotalDays > 7)
                    {
                        item.ValidFlag = "V";
                    }
                    else
                    {
                        item.ValidFlag = "E";
                    }

                    validList.Add(item);
                }

            }


            return validList;
        }

        public bool InsertOrderData(List<Order> Orders, SqlConnection connectionString)
        {
            bool bret = true;

            {
                if(Orders !=null && Orders.Count >0)
                {
                   foreach(var item in Orders)
                    {
                        using (SqlCommand command = connectionString.CreateCommand())
                        {
                            command.CommandText = "Insert into SBA.Orders(OrderId,SalesPersonId,OrderDate,ModelNbr,Quantity,CustomerId,Deliverydate,ValidFlag) Values('" + item.OrderId + "','" + item.SalesPersonId + "','" + item.OrderDate + "','" + item.ModelNbr + "','" + item.Quantity + "','" + item.CustomerId + "','" + item.DeliveryDate + "','" + item.ValidFlag + "')";
                            command.Connection = connectionString;
                            connectionString.Open();
                            int count = command.ExecuteNonQuery();
                            connectionString.Close();
                            if (count > 0)
                            {
                                bret = true;
                            }
                            else

                                bret = false;

                        }
                    }
                }
                else
                {
                    bret = false;
                }
            }
            
            return bret;



        }

        public DataTable GetProductsCommission(SqlConnection connectionString)
        {
            DataTable dtProductsCommission = null;

            using (SqlCommand command = connectionString.CreateCommand())
            {
                command.CommandText = "Select ModelNbr,Commission_Percentage,Base_Price from SBA.Product_Commission";
                command.Connection = connectionString;
                connectionString.Open();
                SqlDataAdapter da = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                da.Fill(ds);
                dtProductsCommission = ds.Tables[0];
            }
            return dtProductsCommission;

        }


        public bool InsertCommissionData(List<Order> Orders, DataTable dtProductsCommission, SqlConnection connectionString)
        {

            bool bret = true;

            if (Orders != null && Orders.Count > 0 && dtProductsCommission.Rows.Count > 0)
            {
                foreach (var item in Orders)
                {
                    if (item.ValidFlag == "V")
                    {
                        foreach (DataRow dr in dtProductsCommission.Rows)
                        {
                            float commamt = Convert.ToInt32(dr["Commission_Percentage"]) * Convert.ToInt32(dr["Base_Price"]) * Convert.ToInt32(item.Quantity);

                            using (SqlCommand cmd = connectionString.CreateCommand())
                            {
                                cmd.CommandText = "Insert into SBA.Order_Commission(OrderId,CommissionAmt) Values('" + item.OrderId + "','" + commamt + "')";
                                connectionString.Open();
                                cmd.ExecuteNonQuery();
                                connectionString.Close();
                                bret = true;
                            }

                        }
                    }
                }
            }

            else
            {
                bret = false;
            }

                    return bret;
        }


        public bool CopyToArchive(string sourceFileName, string sourceFilePath, string archiveFileName, string archiveFilePath)
        {
            bool bret = true;

            if(!File.Exists(archiveFilePath + archiveFileName))
            {
                File.Copy(sourceFilePath + sourceFileName, archiveFilePath + archiveFileName);
                
            }
            else
            {
                File.Delete(archiveFilePath + archiveFileName);

                File.Copy(sourceFilePath + sourceFileName, archiveFilePath + archiveFileName);
            }

            return bret;
        }
    }
} 
 


       
    